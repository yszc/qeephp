<?php

return array(
    'FLEA_Db_Driver_Mysqli' => array(
        'login' => 'root',
        'database' => 'test',
    ),
);
