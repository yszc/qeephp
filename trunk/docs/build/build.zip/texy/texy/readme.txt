texy.compact.php
----------------

This is shrinked single-file version of Texy!, useful when you don't want to modify library, but just use it.

This is exactly the same as normal version, just only comments and whitespace are removed.
