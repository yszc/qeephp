<?php
 /**
 * Texy! - plain text to html converter
 * ------------------------------------
 *
 * Copyright (c) 2004-2007 David Grudl aka -dgx- <dave@dgx.cz>
 *
 * for PHP 5.0.0 and newer
 *
 * @link      http://texy.info/
 * @license   GNU GENERAL PUBLIC LICENSE version 2
 * @package   Texy
 * @category  Text
 * @version   2.0 RC 1 (Revision: 132, Date: 2007/06/08 17:16:44)
 */define('TEXY_DIR',dirname(__FILE__).'/');

define('TEXY_CHAR','A-Za-z\x{C0}-\x{2FF}\x{370}-\x{1EFF}');define('TEXY_MARK',"\x14-\x1F");define('TEXY_MODIFIER','(?: *(?<= |^)\\.((?:\\([^)\\n]+\\)|\\[[^\\]\\n]+\\]|\\{[^}\\n]+\\}){1,3}?))');define('TEXY_MODIFIER_H','(?: *(?<= |^)\\.((?:\\([^)\\n]+\\)|\\[[^\\]\\n]+\\]|\\{[^}\\n]+\\}|<>|>|=|<){1,4}?))');define('TEXY_MODIFIER_HV','(?: *(?<= |^)\\.((?:\\([^)\\n]+\\)|\\[[^\\]\\n]+\\]|\\{[^}\\n]+\\}|<>|>|=|<|\\^|\\-|\\_){1,5}?))');define('TEXY_IMAGE','\[\*([^\n'.TEXY_MARK.']+)'.TEXY_MODIFIER.'? *(\*|>|<)\]');define('TEXY_LINK_URL','(?:\[[^\]\n]+\]|(?!\[)[^\s'.TEXY_MARK.']*?[^:);,.!?\s'.TEXY_MARK.'])');define('TEXY_LINK','(?::('.TEXY_LINK_URL.'))');define('TEXY_LINK_N','(?::('.TEXY_LINK_URL.'|:))');define('TEXY_EMAIL','[a-z0-9.+_-]+@[a-z0-9.+_-]+\.[a-z]{2,}');define('TEXY_URLSCHEME','[a-z][a-z0-9+.-]*:');

class
TexyHtml
implements
ArrayAccess{public$name;public$attrs=array();public$children;public$isEmpty;static
public$xhtml=TRUE;static
private$replacedTags=array('br'=>1,'button'=>1,'iframe'=>1,'img'=>1,'input'=>1,'object'=>1,'script'=>1,'select'=>1,'textarea'=>1,'applet'=>1,'embed'=>1,'canvas'=>1);static
public$emptyTags=array('img'=>1,'hr'=>1,'br'=>1,'input'=>1,'meta'=>1,'area'=>1,'base'=>1,'col'=>1,'link'=>1,'param'=>1,'basefont'=>1,'frame'=>1,'isindex'=>1,'wbr'=>1,'embed'=>1);static
public
function
el($name=NULL,$attrs=NULL){$el=new
self;if($name!==NULL)$el->setName($name);if($attrs!==NULL){if(!is_array($attrs))throw
new
Exception('Attributes must be array');$el->attrs=$attrs;}return$el;}static
public
function
text($text){$el=new
self;$el->setText($text);return$el;}public
function
setName($name){if($name!==NULL&&!is_string($name))throw
new
Exception('Name must be string or NULL');$this->name=$name;$this->isEmpty=isset(self::$emptyTags[$name]);return$this;}public
function
setText($text){if($text===NULL)$text='';elseif(!is_scalar($text))throw
new
Exception('Content must be scalar');$this->children=$text;return$this;}public
function
getText(){if(is_array($this->children))return
FALSE;return$this->children;}public
function
addChild(TexyHtml$child){$this->children[]=$child;return$this;}public
function
getChild($index){if(isset($this->children[$index]))return$this->children[$index];return
NULL;}public
function
add($name,$text=NULL){$child=new
self;$child->setName($name);if($text!==NULL)$child->setText($text);return$this->children[]=$child;}public
function
href($path,$query=NULL){if($query){$query=http_build_query($query,NULL,'&');if($query!=='')$path.='?'.$query;}$this->attrs['href']=$path;return$this;}public
function
offsetGet($i){if(isset($this->attrs[$i])){if(is_array($this->attrs[$i]))$this->attrs[$i]=new
ArrayObject($this->attrs[$i]);return$this->attrs[$i];}if($i==='style'||$i==='class'){return$this->attrs[$i]=new
ArrayObject;}return
NULL;}public
function
offsetSet($i,$value){if($i===NULL)throw
new
Exception('Invalid TexyHtml usage.');$this->attrs[$i]=$value;}public
function
offsetExists($i){return
isset($this->attrs[$i]);}public
function
offsetUnset($i){unset($this->attrs[$i]);}public
function
export($texy){$ct=$this->getContentType();$s=$texy->protect($this->startTag(),$ct);if($this->isEmpty)return$s;if(is_array($this->children)){foreach($this->children
as$val)$s.=$val->export($texy);}else{$s.=$this->children;}return$s.$texy->protect($this->endTag(),$ct);}public
function
startTag(){if(!$this->name)return'';$s='<'.$this->name;if(is_array($this->attrs))foreach($this->attrs
as$key=>$value){if($value===NULL||$value===FALSE)continue;if($value===TRUE){if(self::$xhtml)$s.=' '.$key.'="'.$key.'"';else$s.=' '.$key;continue;}elseif(is_array($value)||is_object($value)){$tmp=NULL;foreach($value
as$k=>$v){if($v==NULL)continue;if(is_string($k))$tmp[]=$k.':'.$v;else$tmp[]=$v;}if(!$tmp)continue;$value=implode($key==='style'?';':' ',$tmp);}elseif($key==='href'&&substr($value,0,7)==='mailto:'){$tmp='';for($i=0;$i<strlen($value);$i++)$tmp.='&#'.ord($value[$i]).';';$s.=' href="'.$tmp.'"';continue;}$value=str_replace(array('&','"','<','>'),array('&amp;','&quot;','&lt;','&gt;'),$value);$s.=' '.$key.'="'.Texy::freezeSpaces($value).'"';}if(self::$xhtml&&$this->isEmpty)return$s.' />';return$s.'>';}public
function
endTag(){if($this->name&&!$this->isEmpty)return'</'.$this->name.'>';return'';}public
function
isTextual(){return!$this->isEmpty&&is_scalar($this->children);}public
function
__clone(){if(is_array($this->children)){foreach($this->children
as$key=>$val)$this->children[$key]=clone$val;}}public
function
getContentType(){if(isset(self::$replacedTags[$this->name]))return
Texy::CONTENT_REPLACED;if(isset(TexyHtmlCleaner::$inline[$this->name]))return
Texy::CONTENT_MARKUP;return
Texy::CONTENT_BLOCK;}public
function
parseLine($texy,$s){$s=str_replace(array('\)','\*'),array('&#x29;','&#x2A;'),$s);$parser=new
TexyLineParser($texy,$this);$parser->parse($s);}public
function
parseBlock($texy,$s,$topLevel=FALSE){$parser=new
TexyBlockParser($texy,$this);$parser->topLevel=$topLevel;$parser->parse($s);}function
__get($nm){throw
new
Exception("Undefined property '".get_class($this)."::$$nm'");}function
__set($nm,$val){$this->__get($nm);}}

class
TexyHtmlCleaner{public$indent=TRUE;public$baseIndent=0;public$lineWrap=80;public$removeOptional=TRUE;private$space;static
public$dtd;static
private$optional=array('colgroup'=>1,'dd'=>1,'dt'=>1,'li'=>1,'option'=>1,'p'=>1,'tbody'=>1,'td'=>1,'tfoot'=>1,'th'=>1,'thead'=>1,'tr'=>1);static
private$prohibits=array('a'=>array('a','button'),'img'=>array('pre'),'object'=>array('pre'),'big'=>array('pre'),'small'=>array('pre'),'sub'=>array('pre'),'sup'=>array('pre'),'input'=>array('button'),'select'=>array('button'),'textarea'=>array('button'),'label'=>array('button','label'),'button'=>array('button'),'form'=>array('button','form'),'fieldset'=>array('button'),'iframe'=>array('button'),'isindex'=>array('button'),);static
public$block=array('ins'=>1,'del'=>1,'p'=>1,'h1'=>1,'h2'=>1,'h3'=>1,'h4'=>1,'h5'=>1,'h6'=>1,'ul'=>1,'ol'=>1,'dl'=>1,'pre'=>1,'div'=>1,'blockquote'=>1,'noscript'=>1,'noframes'=>1,'form'=>1,'hr'=>1,'table'=>1,'address'=>1,'fieldset'=>1);static
public$_blockLoose=array('dir'=>1,'menu'=>1,'center'=>1,'iframe'=>1,'isindex'=>1,'marquee'=>1,);static
public$inline=array('ins'=>1,'del'=>1,'tt'=>1,'i'=>1,'b'=>1,'big'=>1,'small'=>1,'em'=>1,'strong'=>1,'dfn'=>1,'code'=>1,'samp'=>1,'kbd'=>1,'var'=>1,'cite'=>1,'abbr'=>1,'acronym'=>1,'sub'=>1,'sup'=>1,'q'=>1,'span'=>1,'bdo'=>1,'a'=>1,'object'=>1,'img'=>1,'br'=>1,'script'=>1,'map'=>1,'input'=>1,'select'=>1,'textarea'=>1,'label'=>1,'button'=>1,'%DATA'=>1);static
public$_inlineLoose=array('u'=>1,'s'=>1,'strike'=>1,'font'=>1,'applet'=>1,'basefont'=>1,'embed'=>1,'wbr'=>1,'nobr'=>1,'canvas'=>1,);private$tagUsed;private$tagStack;private$texy;private$baseDTD;public
function
__construct($texy){$this->texy=$texy;if(!self::$dtd)self::initDTD();$this->baseDTD=self::$dtd['div'][1]+array('html'=>1);}public
function
process($s){$this->space=$this->baseIndent;$this->tagStack=array();$this->tagUsed=array();$s=preg_replace_callback('#(.*)<(?:(!--.*--)|(/?)([a-z][a-z0-9._:-]*)(|[ \n].*)\s*(/?))>()#Uis',array($this,'cb'),$s.'</end/>');foreach($this->tagStack
as$item)$s.=$item['close'];$s=preg_replace("#[\t ]+(\n|\r|$)#",'$1',$s);$s=str_replace("\r\r","\n",$s);$s=strtr($s,"\r","\n");$s=preg_replace("#\\x07 *#",'',$s);$s=preg_replace("#\\t? *\\x08#",'',$s);if($this->lineWrap>0)$s=preg_replace_callback('#^(\t*)(.*)$#m',array($this,'wrap'),$s);if(!TexyHtml::$xhtml&&$this->removeOptional)$s=preg_replace('#\\s*</(colgroup|dd|dt|li|option|p|td|tfoot|th|thead|tr)>#u','',$s);return$s;}private
function
cb($matches){list(,$mText,$mComment,$mEnd,$mTag,$mAttr,$mEmpty)=$matches;$s='';if($mText!==''){$item=reset($this->tagStack);if($item&&!isset($item['content']['%DATA'])){}elseif(!empty($this->tagUsed['pre'])||!empty($this->tagUsed['textarea']))$s=Texy::freezeSpaces($mText);else$s=preg_replace('#[ \n]+#',' ',$mText);}if($mComment)return$s.'<'.Texy::freezeSpaces($mComment).'>';$mEmpty=$mEmpty||isset(TexyHtml::$emptyTags[$mTag]);if($mEmpty&&$mEnd)return$s;if($mEnd){if(empty($this->tagUsed[$mTag]))return$s;$tmp=array();$back=TRUE;foreach($this->tagStack
as$i=>$item){$tag=$item['tag'];if($item['close']){$s.=$item['close'];if(!isset(self::$inline[$tag]))$this->space--;}$this->tagUsed[$tag]--;$back=$back&&isset(self::$inline[$tag]);unset($this->tagStack[$i]);if($tag===$mTag)break;array_unshift($tmp,$item);}if(!$back||!$tmp)return$s;$item=reset($this->tagStack);if($item)$content=$item['content'];else$content=$this->baseDTD;if(!isset($content[$tmp[0]['tag']]))return$s;foreach($tmp
as$item){if($item['close'])$s.='<'.$item['tag'].$item['attr'].'>';$this->tagUsed[$item['tag']]++;array_unshift($this->tagStack,$item);}}else{$content=$this->baseDTD;if(!isset(self::$dtd[$mTag][1])){$allowed=$this->texy->allowedTags===Texy::ALL;$item=reset($this->tagStack);if($item)$content=$item['content'];}else{foreach($this->tagStack
as$i=>$item){$content=$item['content'];if(isset($content[$mTag]))break;$tag=$item['tag'];if($item['close']&&(!isset(self::$optional[$tag])&&!isset(self::$inline[$tag])))break;if($item['close']){$s.=$item['close'];if(!isset(self::$inline[$tag]))$this->space--;}$this->tagUsed[$tag]--;unset($this->tagStack[$i]);$content=$this->baseDTD;}$allowed=isset($content[$mTag]);if($allowed&&isset(self::$prohibits[$mTag])){foreach(self::$prohibits[$mTag]as$pTag)if(!empty($this->tagUsed[$pTag])){$allowed=FALSE;break;}}}if($mEmpty){if(!$allowed)return$s;if(TexyHtml::$xhtml)$mAttr.=" /";if($this->indent&&$mTag==='br')return
rtrim($s).'<'.$mTag.$mAttr.">\n".str_repeat("\t",max(0,$this->space-1))."\x07";if($this->indent&&!isset(self::$inline[$mTag])){$space="\r".str_repeat("\t",$this->space);return$s.$space.'<'.$mTag.$mAttr.'>'.$space;}return$s.'<'.$mTag.$mAttr.'>';}if($allowed){if(!empty(self::$dtd[$mTag][1]))$content=self::$dtd[$mTag][1];if($this->indent&&!isset(self::$inline[$mTag])){$close="\x08".'</'.$mTag.'>'."\n".str_repeat("\t",$this->space);$s.="\n".str_repeat("\t",$this->space++).'<'.$mTag.$mAttr.'>'."\x07";}else{$close='</'.$mTag.'>';$s.='<'.$mTag.$mAttr.'>';}}else$close='';$item=array('tag'=>$mTag,'attr'=>$mAttr,'close'=>$close,'content'=>$content,);array_unshift($this->tagStack,$item);$tmp=&$this->tagUsed[$mTag];$tmp++;}return$s;}private
function
wrap($m){list(,$space,$s)=$m;return$space.wordwrap($s,$this->lineWrap,"\n".$space);}static
public
function
initDTD(){$strict=Texy::$strictDTD;$coreattrs=array('id'=>1,'class'=>1,'style'=>1,'title'=>1,'xml:id'=>1);$i18n=array('lang'=>1,'dir'=>1,'xml:lang'=>1);$attrs=$coreattrs+$i18n+array('onclick'=>1,'ondblclick'=>1,'onmousedown'=>1,'onmouseup'=>1,'onmouseover'=>1,'onmousemove'=>1,'onmouseout'=>1,'onkeypress'=>1,'onkeydown'=>1,'onkeyup'=>1);$cellalign=$attrs+array('align'=>1,'char'=>1,'charoff'=>1,'valign'=>1);if(!$strict)self::$block+=self::$_blockLoose;$b=self::$block;if(!$strict)self::$inline+=self::$_inlineLoose;$i=self::$inline;$bi=$b+$i;self::$dtd=array('html'=>array($strict?$i18n+array('xmlns'=>1):$i18n+array('version'=>1,'xmlns'=>1),array('head'=>1,'body'=>1),),'head'=>array($i18n+array('profile'=>1),array('title'=>1,'script'=>1,'style'=>1,'base'=>1,'meta'=>1,'link'=>1,'object'=>1,'isindex'=>1),),'title'=>array(array(),array('%DATA'=>1),),'body'=>array($attrs+array('onload'=>1,'onunload'=>1),$strict?array('script'=>1)+$b:$bi,),'script'=>array(array('charset'=>1,'type'=>1,'src'=>1,'defer'=>1,'event'=>1,'for'=>1),array('%DATA'=>1),),'style'=>array($i18n+array('type'=>1,'media'=>1,'title'=>1),array('%DATA'=>1),),'p'=>array($strict?$attrs:$attrs+array('align'=>1),$i,),'h1'=>array($strict?$attrs:$attrs+array('align'=>1),$i,),'h2'=>array($strict?$attrs:$attrs+array('align'=>1),$i,),'h3'=>array($strict?$attrs:$attrs+array('align'=>1),$i,),'h4'=>array($strict?$attrs:$attrs+array('align'=>1),$i,),'h5'=>array($strict?$attrs:$attrs+array('align'=>1),$i,),'h6'=>array($strict?$attrs:$attrs+array('align'=>1),$i,),'ul'=>array($strict?$attrs:$attrs+array('type'=>1,'compact'=>1),array('li'=>1),),'ol'=>array($strict?$attrs:$attrs+array('type'=>1,'compact'=>1,'start'=>1),array('li'=>1),),'li'=>array($strict?$attrs:$attrs+array('type'=>1,'value'=>1),$bi,),'dl'=>array($strict?$attrs:$attrs+array('compact'=>1),array('dt'=>1,'dd'=>1),),'dt'=>array($attrs,$i,),'dd'=>array($attrs,$bi,),'pre'=>array($strict?$attrs:$attrs+array('width'=>1),array_flip(array_diff(array_keys($i),array('img','object','applet','big','small','sub','sup','font','basefont'))),),'div'=>array($strict?$attrs:$attrs+array('align'=>1),$bi,),'blockquote'=>array($attrs+array('cite'=>1),$strict?array('script'=>1)+$b:$bi,),'noscript'=>array($attrs,$bi,),'form'=>array($attrs+array('action'=>1,'method'=>1,'enctype'=>1,'accept'=>1,'name'=>1,'onsubmit'=>1,'onreset'=>1,'accept-charset'=>1),$strict?array('script'=>1)+$b:$bi,),'table'=>array($attrs+array('summary'=>1,'width'=>1,'border'=>1,'frame'=>1,'rules'=>1,'cellspacing'=>1,'cellpadding'=>1,'datapagesize'=>1),array('caption'=>1,'colgroup'=>1,'col'=>1,'thead'=>1,'tbody'=>1,'tfoot'=>1,'tr'=>1),),'caption'=>array($strict?$attrs:$attrs+array('align'=>1),$i,),'colgroup'=>array($cellalign+array('span'=>1,'width'=>1),array('col'=>1),),'thead'=>array($cellalign,array('tr'=>1),),'tbody'=>array($cellalign,array('tr'=>1),),'tfoot'=>array($cellalign,array('tr'=>1),),'tr'=>array($strict?$cellalign:$cellalign+array('bgcolor'=>1),array('td'=>1,'th'=>1),),'td'=>array($cellalign+array('abbr'=>1,'axis'=>1,'headers'=>1,'scope'=>1,'rowspan'=>1,'colspan'=>1),$bi,),'th'=>array($cellalign+array('abbr'=>1,'axis'=>1,'headers'=>1,'scope'=>1,'rowspan'=>1,'colspan'=>1),$bi,),'address'=>array($attrs,$strict?$i:array('p'=>1)+$i,),'fieldset'=>array($attrs,array('legend'=>1)+$bi,),'legend'=>array($strict?$attrs+array('accesskey'=>1):$attrs+array('accesskey'=>1,'align'=>1),$i,),'tt'=>array($attrs,$i,),'i'=>array($attrs,$i,),'b'=>array($attrs,$i,),'big'=>array($attrs,$i,),'small'=>array($attrs,$i,),'em'=>array($attrs,$i,),'strong'=>array($attrs,$i,),'dfn'=>array($attrs,$i,),'code'=>array($attrs,$i,),'samp'=>array($attrs,$i,),'kbd'=>array($attrs,$i,),'var'=>array($attrs,$i,),'cite'=>array($attrs,$i,),'abbr'=>array($attrs,$i,),'acronym'=>array($attrs,$i,),'sub'=>array($attrs,$i,),'sup'=>array($attrs,$i,),'q'=>array($attrs+array('cite'=>1),$i,),'span'=>array($attrs,$i,),'bdo'=>array($coreattrs+array('lang'=>1,'dir'=>1),$i,),'a'=>array($attrs+array('charset'=>1,'type'=>1,'name'=>1,'href'=>1,'hreflang'=>1,'rel'=>1,'rev'=>1,'accesskey'=>1,'shape'=>1,'coords'=>1,'tabindex'=>1,'onfocus'=>1,'onblur'=>1),$i,),'object'=>array($attrs+array('declare'=>1,'classid'=>1,'codebase'=>1,'data'=>1,'type'=>1,'codetype'=>1,'archive'=>1,'standby'=>1,'height'=>1,'width'=>1,'usemap'=>1,'name'=>1,'tabindex'=>1),array('param'=>1)+$bi,),'map'=>array($attrs+array('name'=>1),array('area'=>1)+$b,),'select'=>array($attrs+array('name'=>1,'size'=>1,'multiple'=>1,'disabled'=>1,'tabindex'=>1,'onfocus'=>1,'onblur'=>1,'onchange'=>1),array('option'=>1,'optgroup'=>1),),'optgroup'=>array($attrs+array('disabled'=>1,'label'=>1),array('option'=>1),),'option'=>array($attrs+array('selected'=>1,'disabled'=>1,'label'=>1,'value'=>1),array('%DATA'=>1),),'textarea'=>array($attrs+array('name'=>1,'rows'=>1,'cols'=>1,'disabled'=>1,'readonly'=>1,'tabindex'=>1,'accesskey'=>1,'onfocus'=>1,'onblur'=>1,'onselect'=>1,'onchange'=>1),array('%DATA'=>1),),'label'=>array($attrs+array('for'=>1,'accesskey'=>1,'onfocus'=>1,'onblur'=>1),$i,),'button'=>array($attrs+array('name'=>1,'value'=>1,'type'=>1,'disabled'=>1,'tabindex'=>1,'accesskey'=>1,'onfocus'=>1,'onblur'=>1),$bi,),'ins'=>array($attrs+array('cite'=>1,'datetime'=>1),0,),'del'=>array($attrs+array('cite'=>1,'datetime'=>1),0,),'img'=>array($attrs+array('src'=>1,'alt'=>1,'longdesc'=>1,'name'=>1,'height'=>1,'width'=>1,'usemap'=>1,'ismap'=>1),FALSE,),'hr'=>array($strict?$attrs:$attrs+array('align'=>1,'noshade'=>1,'size'=>1,'width'=>1),FALSE,),'br'=>array($strict?$coreattrs:$coreattrs+array('clear'=>1),FALSE,),'input'=>array($attrs+array('type'=>1,'name'=>1,'value'=>1,'checked'=>1,'disabled'=>1,'readonly'=>1,'size'=>1,'maxlength'=>1,'src'=>1,'alt'=>1,'usemap'=>1,'ismap'=>1,'tabindex'=>1,'accesskey'=>1,'onfocus'=>1,'onblur'=>1,'onselect'=>1,'onchange'=>1,'accept'=>1),FALSE,),'meta'=>array($i18n+array('http-equiv'=>1,'name'=>1,'content'=>1,'scheme'=>1),FALSE,),'area'=>array($attrs+array('shape'=>1,'coords'=>1,'href'=>1,'nohref'=>1,'alt'=>1,'tabindex'=>1,'accesskey'=>1,'onfocus'=>1,'onblur'=>1),FALSE,),'base'=>array($strict?array('href'=>1):array('href'=>1,'target'=>1),FALSE,),'col'=>array($cellalign+array('span'=>1,'width'=>1),FALSE,),'link'=>array($attrs+array('charset'=>1,'href'=>1,'hreflang'=>1,'type'=>1,'rel'=>1,'rev'=>1,'media'=>1),FALSE,),'param'=>array(array('id'=>1,'name'=>1,'value'=>1,'valuetype'=>1,'type'=>1),FALSE,),);if($strict)return;self::$dtd+=array('dir'=>array($attrs+array('compact'=>1),array('li'=>1),),'menu'=>array($attrs+array('compact'=>1),array('li'=>1),),'center'=>array($attrs,$bi,),'iframe'=>array($coreattrs+array('longdesc'=>1,'name'=>1,'src'=>1,'frameborder'=>1,'marginwidth'=>1,'marginheight'=>1,'scrolling'=>1,'align'=>1,'height'=>1,'width'=>1),$bi,),'noframes'=>array($attrs,$bi,),'u'=>array($attrs,$i,),'s'=>array($attrs,$i,),'strike'=>array($attrs,$i,),'font'=>array($coreattrs+$i18n+array('size'=>1,'color'=>1,'face'=>1),$i,),'applet'=>array($coreattrs+array('codebase'=>1,'archive'=>1,'code'=>1,'object'=>1,'alt'=>1,'name'=>1,'width'=>1,'height'=>1,'align'=>1,'hspace'=>1,'vspace'=>1),array('param'=>1)+$bi,),'basefont'=>array(array('id'=>1,'size'=>1,'color'=>1,'face'=>1),FALSE,),'isindex'=>array($coreattrs+$i18n+array('prompt'=>1),FALSE,),'marquee'=>array(Texy::ALL,$bi,),'nobr'=>array(array(),$i,),'canvas'=>array(Texy::ALL,$i,),'embed'=>array(Texy::ALL,FALSE,),'wbr'=>array(array(),FALSE,),);self::$dtd['a'][0]+=array('target'=>1);self::$dtd['area'][0]+=array('target'=>1);self::$dtd['body'][0]+=array('background'=>1,'bgcolor'=>1,'text'=>1,'link'=>1,'vlink'=>1,'alink'=>1);self::$dtd['form'][0]+=array('target'=>1);self::$dtd['img'][0]+=array('align'=>1,'border'=>1,'hspace'=>1,'vspace'=>1);self::$dtd['input'][0]+=array('align'=>1);self::$dtd['link'][0]+=array('target'=>1);self::$dtd['object'][0]+=array('align'=>1,'border'=>1,'hspace'=>1,'vspace'=>1);self::$dtd['script'][0]+=array('language'=>1);self::$dtd['table'][0]+=array('align'=>1,'bgcolor'=>1);self::$dtd['td'][0]+=array('nowrap'=>1,'bgcolor'=>1,'width'=>1,'height'=>1);self::$dtd['th'][0]+=array('nowrap'=>1,'bgcolor'=>1,'width'=>1,'height'=>1);}function
__get($nm){throw
new
Exception("Undefined property '".get_class($this)."::$$nm'");}function
__set($nm,$val){$this->__get($nm);}}

class
TexyModifier{const
HALIGN_LEFT='left';const
HALIGN_RIGHT='right';const
HALIGN_CENTER='center';const
HALIGN_JUSTIFY='justify';const
VALIGN_TOP='top';const
VALIGN_MIDDLE='middle';const
VALIGN_BOTTOM='bottom';public$empty=TRUE;public$id;public$classes=array();public$styles=array();public$attrs=array();public$hAlign;public$vAlign;public$title;public$cite;static
public$elAttrs=array('abbr'=>1,'accesskey'=>1,'align'=>1,'alt'=>1,'archive'=>1,'axis'=>1,'bgcolor'=>1,'cellpadding'=>1,'cellspacing'=>1,'char'=>1,'charoff'=>1,'charset'=>1,'cite'=>1,'classid'=>1,'codebase'=>1,'codetype'=>1,'colspan'=>1,'compact'=>1,'coords'=>1,'data'=>1,'datetime'=>1,'declare'=>1,'dir'=>1,'face'=>1,'frame'=>1,'headers'=>1,'href'=>1,'hreflang'=>1,'hspace'=>1,'ismap'=>1,'lang'=>1,'longdesc'=>1,'name'=>1,'noshade'=>1,'nowrap'=>1,'onblur'=>1,'onclick'=>1,'ondblclick'=>1,'onkeydown'=>1,'onkeypress'=>1,'onkeyup'=>1,'onmousedown'=>1,'onmousemove'=>1,'onmouseout'=>1,'onmouseover'=>1,'onmouseup'=>1,'rel'=>1,'rev'=>1,'rowspan'=>1,'rules'=>1,'scope'=>1,'shape'=>1,'size'=>1,'span'=>1,'src'=>1,'standby'=>1,'start'=>1,'summary'=>1,'tabindex'=>1,'target'=>1,'title'=>1,'type'=>1,'usemap'=>1,'valign'=>1,'value'=>1,'vspace'=>1,);public
function
__construct($mod=NULL){$this->setProperties($mod);}public
function
setProperties($mod){if(!$mod)return;$this->empty=FALSE;$p=0;$len=strlen($mod);while($p<$len){$ch=$mod[$p];if($ch==='('){$a=strpos($mod,')',$p)+1;$this->title=Texy::unescapeHtml(trim(substr($mod,$p+1,$a-$p-2)));$p=$a;}elseif($ch==='{'){$a=strpos($mod,'}',$p)+1;foreach(explode(';',substr($mod,$p+1,$a-$p-2))as$value){$pair=explode(':',$value,2);$prop=strtolower(trim($pair[0]));if($prop===''||!isset($pair[1]))continue;$value=trim($pair[1]);if(isset(self::$elAttrs[$prop]))$this->attrs[$prop]=$value;elseif($value!=='')$this->styles[$prop]=$value;}$p=$a;}elseif($ch==='['){$a=strpos($mod,']',$p)+1;$s=str_replace('#',' #',substr($mod,$p+1,$a-$p-2));foreach(explode(' ',$s)as$value){if($value==='')continue;if($value{0}==='#')$this->id=substr($value,1);else$this->classes[]=$value;}$p=$a;}elseif($ch==='^'){$this->vAlign=self::VALIGN_TOP;$p++;}elseif($ch==='-'){$this->vAlign=self::VALIGN_MIDDLE;$p++;}elseif($ch==='_'){$this->vAlign=self::VALIGN_BOTTOM;$p++;}elseif($ch==='='){$this->hAlign=self::HALIGN_JUSTIFY;$p++;}elseif($ch==='>'){$this->hAlign=self::HALIGN_RIGHT;$p++;}elseif(substr($mod,$p,2)==='<>'){$this->hAlign=self::HALIGN_CENTER;$p+=2;}elseif($ch==='<'){$this->hAlign=self::HALIGN_LEFT;$p++;}else{break;}}}public
function
decorate($texy,$el){$elAttrs=&$el->attrs;$tmp=$texy->allowedTags;if(!$this->attrs){}elseif($tmp===Texy::ALL){$elAttrs=$this->attrs;}elseif(is_array($tmp)&&isset($tmp[$el->name])){$tmp=$tmp[$el->name];if($tmp===Texy::ALL){$elAttrs=$this->attrs;}elseif(is_array($tmp)&&count($tmp)){$tmp=array_flip($tmp);foreach($this->attrs
as$key=>$val)if(isset($tmp[$key]))$el->attrs[$key]=$val;}}if($this->title!==NULL)$elAttrs['title']=$texy->typographyModule->postLine($this->title);if($this->classes||$this->id!==NULL){$tmp=$texy->_classes;if($tmp===Texy::ALL){foreach($this->classes
as$val)$elAttrs['class'][]=$val;$elAttrs['id']=$this->id;}elseif(is_array($tmp)){foreach($this->classes
as$val)if(isset($tmp[$val]))$elAttrs['class'][]=$val;if(isset($tmp['#'.$this->id]))$elAttrs['id']=$this->id;}}if($this->styles){$tmp=$texy->_styles;if($tmp===Texy::ALL){foreach($this->styles
as$prop=>$val)$elAttrs['style'][$prop]=$val;}elseif(is_array($tmp)){foreach($this->styles
as$prop=>$val)if(isset($tmp[$prop]))$elAttrs['style'][$prop]=$val;}}if($this->hAlign)$elAttrs['style']['text-align']=$this->hAlign;if($this->vAlign)$elAttrs['style']['vertical-align']=$this->vAlign;return$el;}function
__get($nm){throw
new
Exception("Undefined property '".get_class($this)."::$$nm'");}function
__set($nm,$val){$this->__get($nm);}}

abstract
class
TexyModule{protected$texy;protected$syntax=array();public
function
__construct($texy){$this->texy=$texy;$texy->registerModule($this);$texy->allowed=array_merge($texy->allowed,$this->syntax);}public
function
begin(){}function
__get($nm){throw
new
Exception("Undefined property '".get_class($this)."::$$nm'");}function
__set($nm,$val){$this->__get($nm);}}interface
ITexyPreBlock{public
function
preBlock($block,$topLevel);}interface
ITexyPostLine{public
function
postLine($line);}

class
TexyParser{public$texy;public$parent;public$patterns;function
__get($nm){throw
new
Exception("Undefined property '".get_class($this)."::$$nm'");}function
__set($nm,$val){$this->__get($nm);}}class
TexyBlockParser
extends
TexyParser{private$text;private$offset;public$topLevel=FALSE;public
function
__construct(Texy$texy,$element=NULL){$this->texy=$texy;$this->parent=$element;$this->patterns=$texy->getBlockPatterns();}public
function
next($pattern,&$matches){$matches=NULL;$ok=preg_match($pattern.'Am',$this->text,$matches,PREG_OFFSET_CAPTURE,$this->offset);if($ok){$this->offset+=strlen($matches[0][0])+1;foreach($matches
as$key=>$value)$matches[$key]=$value[0];}return$ok;}public
function
moveBackward($linesCount=1){while(--$this->offset>0)if($this->text{$this->offset-1}==="\n"){$linesCount--;if($linesCount<1)break;}$this->offset=max($this->offset,0);}public
function
parse($text){$tx=$this->texy;foreach($tx->_preBlockModules
as$module)$text=$module->preBlock($text,$this->topLevel);$this->text=$text;$this->offset=0;$nodes=array();$hasHandler=is_callable(array($tx->handler,'paragraph'));$pb=$this->patterns;if(!$pb)return
array();$keys=array_keys($pb);$arrMatches=$arrPos=array();foreach($keys
as$key)$arrPos[$key]=-1;do{$minKey=NULL;$minPos=strlen($text);if($this->offset>=$minPos)break;foreach($keys
as$index=>$key){if($arrPos[$key]<$this->offset){$delta=($arrPos[$key]===-2)?1:0;if(preg_match($pb[$key]['pattern'],$text,$arrMatches[$key],PREG_OFFSET_CAPTURE,$this->offset+$delta)){$m=&$arrMatches[$key];$arrPos[$key]=$m[0][1];foreach($m
as$keyX=>$valueX)$m[$keyX]=$valueX[0];}else{unset($keys[$index]);continue;}}if($arrPos[$key]===$this->offset){$minKey=$key;break;}if($arrPos[$key]<$minPos){$minPos=$arrPos[$key];$minKey=$key;}}$next=($minKey===NULL)?strlen($text):$arrPos[$minKey];if($next>$this->offset){$str=substr($text,$this->offset,$next-$this->offset);$this->offset=$next;if($tx->paragraphModule->mode)$parts=preg_split('#(\n{2,})#',$str);else$parts=preg_split('#(\n(?! )|\n{2,})#',$str);foreach($parts
as$str){$str=trim($str);$mod=new
TexyModifier;$matches=NULL;if(preg_match('#\A(.*)(?<=\A|\S)'.TEXY_MODIFIER_H.'(\n.*)?()\z#sUm',$str,$matches)){list(,$mC1,$mMod,$mC2)=$matches;$str=trim($mC1.$mC2);$mod->setProperties($mMod);}$el=Texy::PROCEED;if($hasHandler)$el=$tx->handler->paragraph($this,$str,$mod);if($el===Texy::PROCEED)$el=$tx->paragraphModule->solve($str,$mod);if($el)$nodes[]=$el;}continue;}$px=$pb[$minKey];$this->offset=$arrPos[$minKey]+strlen($arrMatches[$minKey][0])+1;$res=call_user_func_array($px['handler'],array($this,$arrMatches[$minKey],$minKey));if($res===FALSE||$this->offset<=$arrPos[$minKey]){$this->offset=$arrPos[$minKey];$arrPos[$minKey]=-2;continue;}elseif($res
instanceof
TexyHtml){$nodes[]=$res;}elseif(is_string($res)){$nodes[]=TexyHtml::text($res);}$arrPos[$minKey]=-1;}while(1);if($this->parent)$this->parent->children=$nodes;return$nodes;}}class
TexyLineParser
extends
TexyParser{public$again;public
function
__construct(Texy$texy,$element=NULL){$this->texy=$texy;$this->parent=$element;$this->patterns=$texy->getLinePatterns();}public
function
parse($text){$tx=$this->texy;$pl=$this->patterns;if(!$pl)return$text;$offset=0;$keys=array_keys($pl);$arrMatches=$arrPos=array();foreach($keys
as$key)$arrPos[$key]=-1;do{$minKey=NULL;$minPos=strlen($text);foreach($keys
as$index=>$key){if($arrPos[$key]<$offset){$delta=($arrPos[$key]===-2)?1:0;if(preg_match($pl[$key]['pattern'],$text,$arrMatches[$key],PREG_OFFSET_CAPTURE,$offset+$delta)){$m=&$arrMatches[$key];if(!strlen($m[0][0]))continue;$arrPos[$key]=$m[0][1];foreach($m
as$keyx=>$value)$m[$keyx]=$value[0];}else{unset($keys[$index]);continue;}}if($arrPos[$key]<$minPos){$minPos=$arrPos[$key];$minKey=$key;}}if($minKey===NULL)break;$px=$pl[$minKey];$offset=$start=$arrPos[$minKey];$this->again=FALSE;$res=call_user_func_array($px['handler'],array($this,$arrMatches[$minKey],$minKey));if($res
instanceof
TexyHtml){$res=$res->export($tx);}elseif($res===FALSE){$arrPos[$minKey]=-2;continue;}$len=strlen($arrMatches[$minKey][0]);$text=substr_replace($text,(string)$res,$start,$len);$delta=strlen($res)-$len;foreach($keys
as$key){if($arrPos[$key]<$start+$len)$arrPos[$key]=-1;else$arrPos[$key]+=$delta;}if($this->again){$arrPos[$minKey]=-2;}else{$arrPos[$minKey]=-1;$offset+=strlen($res);}}while(1);if($this->parent)$this->parent->setText($text);return$text;}}

class
TexyUtf{static
private$xlat;static
private$xlatCache;static
public
function
toUtf($s,$encoding){return
iconv($encoding,'UTF-8',$s);}static
public
function
utfTo($s,$encoding){return
iconv('utf-8',$encoding.'//TRANSLIT',$s);}static
public
function
strtolower($s){if(function_exists('mb_strtolower'))return
mb_strtolower($s,'UTF-8');return
strtr(iconv('UTF-8','WINDOWS-1250//IGNORE',$s),"ABCDEFGHIJKLMNOPQRSTUVWXYZ\x8a\x8c\x8d\x8e\x8f\xa3\xa5\xaa\xaf\xbc\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd8\xd9\xda\xdb\xdc\xdd\xde","abcdefghijklmnopqrstuvwxyz\x9a\x9c\x9d\x9e\x9f\xb3\xb9\xba\xbf\xbe\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf8\xf9\xfa\xfb\xfc\xfd\xfe");}static
public
function
utf2ascii($s){$s=iconv('UTF-8','WINDOWS-1250//IGNORE',$s);return
strtr($s,"\xa5\xa3\xbc\x8c\xa7\x8a\xaa\x8d\x8f\x8e\xaf\xb9\xb3\xbe\x9c\x9a\xba\x9d\x9f\x9e\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf8\xf9\xfa\xfb\xfc\xfd\xfe","ALLSSSSTZZZallssstzzzRAAAALCCCEEEEIIDDNNOOOOxRUUUUYTsraaaalccceeeeiiddnnooooruuuuyt");}static
public
function
utf2html($s,$encoding){if(strcasecmp($encoding,'utf-8')===0)return$s;self::$xlat=&self::$xlatCache[strtolower($encoding)];if(!self::$xlat){for($i=128;$i<256;$i++){$ch=iconv($encoding,'UTF-8//IGNORE',chr($i));if($ch)self::$xlat[$ch]=chr($i);}}return
preg_replace_callback('#[\x80-\x{FFFF}]#u',array(__CLASS__,'cb'),$s);}static
private
function
cb($m){$m=$m[0];if(isset(self::$xlat[$m]))return
self::$xlat[$m];$ch1=ord($m[0]);$ch2=ord($m[1]);if(($ch2>>6)!==2)return'';if(($ch1&0xE0)===0xC0)return'&#'.((($ch1&0x1F)<<6)+($ch2&0x3F)).';';if(($ch1&0xF0)===0xE0){$ch3=ord($m[2]);if(($ch3>>6)!==2)return'';return'&#'.((($ch1&0xF)<<12)+(($ch2&0x3F)<<06)+(($ch3&0x3F))).';';}return'';}}

class
TexyConfigurator{static
public$safeTags=array('a'=>array('href','title'),'acronym'=>array('title'),'b'=>array(),'br'=>array(),'cite'=>array(),'code'=>array(),'em'=>array(),'i'=>array(),'strong'=>array(),'sub'=>array(),'sup'=>array(),'q'=>array(),'small'=>array(),);static
public
function
safeMode(Texy$texy){$texy->allowedClasses=Texy::NONE;$texy->allowedStyles=Texy::NONE;$texy->allowedTags=self::$safeTags;$texy->urlSchemeFilters['a']='#https?:|ftp:|mailto:#A';$texy->urlSchemeFilters['i']='#https?:#A';$texy->urlSchemeFilters['c']='#http:#A';$texy->allowed['image']=FALSE;$texy->allowed['link/definition']=FALSE;$texy->allowed['html/comment']=FALSE;$texy->linkModule->forceNoFollow=TRUE;}static
public
function
trustMode(Texy$texy){trigger_error('trustMode() is deprecated. Trust configuration is by default.',E_USER_WARNING);$texy->allowedClasses=Texy::ALL;$texy->allowedStyles=Texy::ALL;$texy->allowedTags=array();foreach(TexyHtmlCleaner::$dtd
as$tag=>$dtd)$texy->allowedTags[$tag]=is_array($dtd[0])?array_keys($dtd[0]):$dtd[0];$texy->urlSchemeFilters=NULL;$texy->allowed['image']=TRUE;$texy->allowed['link/definition']=TRUE;$texy->allowed['html/comment']=TRUE;$texy->linkModule->forceNoFollow=FALSE;}static
public
function
disableLinks(Texy$texy){$texy->allowed['link/reference']=FALSE;$texy->allowed['link/email']=FALSE;$texy->allowed['link/url']=FALSE;$texy->allowed['link/definition']=FALSE;$texy->phraseModule->linksAllowed=FALSE;if(is_array($texy->allowedTags))unset($texy->allowedTags['a']);}static
public
function
disableImages(Texy$texy){$texy->allowed['image']=FALSE;$texy->allowed['figure']=FALSE;$texy->allowed['image/definition']=FALSE;if(is_array($texy->allowedTags))unset($texy->allowedTags['img'],$texy->allowedTags['object'],$texy->allowedTags['embed'],$texy->allowedTags['applet']);}}

class
TexyParagraphModule
extends
TexyModule{public$mode;public
function
begin(){$this->mode=TRUE;}public
function
solve($content,$mod){$tx=$this->texy;if($tx->mergeLines){$content=preg_replace('#\n (?=\S)#',"\r",$content);}else{$content=preg_replace('#\n#',"\r",$content);}$el=TexyHtml::el('p');$el->parseLine($tx,$content);$content=$el->getText();if(strpos($content,Texy::CONTENT_BLOCK)!==FALSE){$el->name='';}elseif(strpos($content,Texy::CONTENT_TEXTUAL)!==FALSE){}elseif(preg_match('#[^\s'.TEXY_MARK.']#u',$content)){}elseif(strpos($content,Texy::CONTENT_REPLACED)!==FALSE){$el->name='div';}else{if($tx->ignoreEmptyStuff)return
FALSE;if($mod->empty)$el->name='';}if($el->name&&$mod)$mod->decorate($tx,$el);if($el->name&&(strpos($content,"\r")!==FALSE)){$key=$tx->protect('<br />',Texy::CONTENT_REPLACED);$content=str_replace("\r",$key,$content);};$content=strtr($content,"\r\n",'  ');$el->setText($content);return$el;}}

class
TexyBlockModule
extends
TexyModule
implements
ITexyPreBlock{protected$syntax=array('blocks'=>TRUE,'block/default'=>TRUE,'block/pre'=>TRUE,'block/code'=>TRUE,'block/html'=>TRUE,'block/text'=>TRUE,'block/texysource'=>TRUE,'block/comment'=>TRUE,'block/div'=>TRUE,);public
function
begin(){$this->texy->registerBlockPattern(array($this,'pattern'),'#^/--++ *+(.*)'.TEXY_MODIFIER_H.'?$((?:\n(?0)|\n.*+)*)(?:\n\\\\--.*$|\z)#mUi','blocks');}public
function
preBlock($text,$topLevel){$text=preg_replace('#^(/--++ *+(?!div|texysource).*)$((?:\n.*+)*?)(?:\n\\\\--.*$|(?=(\n/--.*$)))#mi',"\$1\$2\n\\--",$text);return$text;}public
function
pattern($parser,$matches){list(,$mParam,$mMod,$mContent)=$matches;$mod=new
TexyModifier($mMod);$parts=preg_split('#\s+#u',$mParam,2);$blocktype=empty($parts[0])?'block/default':'block/'.$parts[0];$param=empty($parts[1])?NULL:$parts[1];if(is_callable(array($this->texy->handler,'block'))){$res=$this->texy->handler->block($parser,$blocktype,$mContent,$param,$mod);if($res!==Texy::PROCEED)return$res;}return$this->solve($blocktype,$mContent,$param,$mod);}public
function
outdent($s){$s=trim($s,"\n");$spaces=strspn($s,' ');if($spaces)return
preg_replace("#^ {1,$spaces}#m",'',$s);return$s;}public
function
solve($blocktype,$s,$param,$mod){$tx=$this->texy;if($blocktype==='block/texy'){$el=TexyHtml::el();$el->parseBlock($tx,$s);return$el;}if(empty($tx->allowed[$blocktype]))return
FALSE;if($blocktype==='block/texysource'){$s=$this->outdent($s);if($s==='')return"\n";$el=TexyHtml::el();if($param==='line')$el->parseLine($tx,$s);else$el->parseBlock($tx,$s);$s=$tx->_toHtml($el->export($tx));$blocktype='block/code';$param='html';}if($blocktype==='block/code'){$s=$this->outdent($s);if($s==='')return"\n";$s=Texy::escapeHtml($s);$s=$tx->protect($s);$el=TexyHtml::el('pre');$mod->decorate($tx,$el);$el->attrs['class'][]=$param;$el->add('code',$s);return$el;}if($blocktype==='block/default'){$s=$this->outdent($s);if($s==='')return"\n";$el=TexyHtml::el('pre');$mod->decorate($tx,$el);$el->attrs['class'][]=$param;$s=Texy::escapeHtml($s);$s=$tx->protect($s);$el->setText($s);return$el;}if($blocktype==='block/pre'){$s=$this->outdent($s);if($s==='')return"\n";$el=TexyHtml::el('pre');$mod->decorate($tx,$el);$lineParser=new
TexyLineParser($tx);$tmp=$lineParser->patterns;$lineParser->patterns=array();if(isset($tmp['html/tag']))$lineParser->patterns['html/tag']=$tmp['html/tag'];if(isset($tmp['html/comment']))$lineParser->patterns['html/comment']=$tmp['html/comment'];unset($tmp);$s=$lineParser->parse($s);$s=Texy::unescapeHtml($s);$s=Texy::escapeHtml($s);$s=$tx->unprotect($s);$s=$tx->protect($s);$el->setText($s);return$el;}if($blocktype==='block/html'){$s=trim($s,"\n");if($s==='')return"\n";$lineParser=new
TexyLineParser($tx);$tmp=$lineParser->patterns;$lineParser->patterns=array();if(isset($tmp['html/tag']))$lineParser->patterns['html/tag']=$tmp['html/tag'];if(isset($tmp['html/comment']))$lineParser->patterns['html/comment']=$tmp['html/comment'];unset($tmp);$s=$lineParser->parse($s);$s=Texy::unescapeHtml($s);$s=Texy::escapeHtml($s);$s=$tx->unprotect($s);return$tx->protect($s)."\n";}if($blocktype==='block/text'){$s=trim($s,"\n");if($s==='')return"\n";$s=Texy::escapeHtml($s);$s=str_replace("\n",TexyHtml::el('br')->startTag(),$s);return$tx->protect($s)."\n";}if($blocktype==='block/comment'){return"\n";}if($blocktype==='block/div'){$s=$this->outdent($s);if($s==='')return"\n";$el=TexyHtml::el('div');$mod->decorate($tx,$el);$el->parseBlock($tx,$s);return$el;}return
FALSE;}}

class
TexyHeadingModule
extends
TexyModule{const
DYNAMIC=1,FIXED=2;protected$syntax=array('heading/surrounded'=>TRUE,'heading/underlined'=>TRUE);public$title;public$TOC;public$generateID=FALSE;public$idPrefix='toc-';public$top=1;public$balancing=TexyHeadingModule::DYNAMIC;public$levels=array('#'=>0,'*'=>1,'='=>2,'-'=>3,);private$usedID;private$dynamicMap;private$dynamicTop;public
function
begin(){$this->texy->registerBlockPattern(array($this,'patternUnderline'),'#^(\S.*)'.TEXY_MODIFIER_H.'?\n'.'(\#{3,}|\*{3,}|={3,}|-{3,})$#mU','heading/underlined');$this->texy->registerBlockPattern(array($this,'patternSurround'),'#^(\#{2,}+|={2,}+)(.+)'.TEXY_MODIFIER_H.'?()$#mU','heading/surrounded');$this->title=NULL;$this->usedID=array();$this->TOC=array();$foo1=array();$this->dynamicMap=&$foo1;$foo2=-100;$this->dynamicTop=&$foo2;}public
function
patternUnderline($parser,$matches){list(,$mContent,$mMod,$mLine)=$matches;$mod=new
TexyModifier($mMod);$level=$this->levels[$mLine[0]];if(is_callable(array($this->texy->handler,'heading'))){$res=$this->texy->handler->heading($parser,$level,$mContent,$mod,FALSE);if($res!==Texy::PROCEED)return$res;}return$this->solve($level,$mContent,$mod,FALSE);}public
function
patternSurround($parser,$matches){list(,$mLine,$mContent,$mMod)=$matches;$mod=new
TexyModifier($mMod);$level=7-min(7,max(2,strlen($mLine)));$mContent=rtrim($mContent,$mLine[0].' ');if(is_callable(array($this->texy->handler,'heading'))){$res=$this->texy->handler->heading($parser,$level,$mContent,$mod,TRUE);if($res!==Texy::PROCEED)return$res;}return$this->solve($level,$mContent,$mod,TRUE);}public
function
solve($level,$content,$mod,$isSurrounded){$tx=$this->texy;$el=new
TexyHeadingElement;$mod->decorate($tx,$el);$el->level=$level;$el->top=$this->top;if($this->balancing===self::DYNAMIC){if($isSurrounded){$this->dynamicTop=max($this->dynamicTop,$this->top-$level);$el->top=&$this->dynamicTop;}else{$this->dynamicMap[$level]=$level;$el->map=&$this->dynamicMap;}}$el->parseLine($tx,trim($content));$title=$tx->_toText($el->getText());if($this->title===NULL)$this->title=$title;if($this->generateID&&empty($el->attrs['id'])){$id=$this->idPrefix.Texy::webalize($title);$counter='';if(isset($this->usedID[$id.$counter])){$counter=2;while(isset($this->usedID[$id.'-'.$counter]))$counter++;$id.='-'.$counter;}$this->usedID[$id]=TRUE;$el->attrs['id']=$id;}$TOC=array('id'=>isset($el->attrs['id'])?$el->attrs['id']:NULL,'title'=>$title,'level'=>0,);$this->TOC[]=&$TOC;$el->TOC=&$TOC;return$el;}}class
TexyHeadingElement
extends
TexyHtml{public$name='h?';public$level;public$top;public$map;public$TOC;public
function
startTag(){$level=$this->level;if($this->map){asort($this->map);$level=array_search($level,array_values($this->map),TRUE);}$level+=$this->top;$this->name='h'.min(6,max(1,$level));$this->TOC['level']=$level;return
parent::startTag();}}

class
TexyHorizLineModule
extends
TexyModule{protected$syntax=array('horizline'=>TRUE);public
function
begin(){$this->texy->registerBlockPattern(array($this,'pattern'),'#^(?:\*{3,}|-{3,})\ *'.TEXY_MODIFIER.'?()$#mU','horizline');}public
function
pattern($parser,$matches){list(,$mMod)=$matches;$tx=$this->texy;$el=TexyHtml::el('hr');$mod=new
TexyModifier($mMod);$mod->decorate($tx,$el);if(is_callable(array($tx->handler,'afterHorizline')))$tx->handler->afterHorizline($parser,$el,$mod);return$el;}}

class
TexyHtmlModule
extends
TexyModule{protected$syntax=array('html/tag'=>TRUE,'html/comment'=>TRUE,);public$passComment=TRUE;public
function
begin(){$this->texy->registerLinePattern(array($this,'patternTag'),'#<(/?)([a-z][a-z0-9_:-]*)((?:\s+[a-z0-9:-]+|=\s*"[^"'.TEXY_MARK.']*"|=\s*\'[^\''.TEXY_MARK.']*\'|=[^\s>'.TEXY_MARK.']+)*)\s*(/?)>#isu','html/tag');$this->texy->registerLinePattern(array($this,'patternComment'),'#<!--([^'.TEXY_MARK.']*?)-->#is','html/comment');}public
function
patternComment($parser,$matches){list(,$mComment)=$matches;if(is_callable(array($this->texy->handler,'htmlComment'))){$res=$this->texy->handler->htmlComment($parser,$mComment);if($res!==Texy::PROCEED)return$res;}return$this->solveComment($mComment);}public
function
patternTag($parser,$matches){list(,$mEnd,$mTag,$mAttr,$mEmpty)=$matches;$tx=$this->texy;$isStart=$mEnd!=='/';$isEmpty=$mEmpty==='/';if(!$isEmpty&&substr($mAttr,-1)==='/'){$mAttr=substr($mAttr,0,-1);$isEmpty=TRUE;}if($isEmpty&&!$isStart)return
FALSE;$mAttr=trim(strtr($mAttr,"\n",' '));if($mAttr&&!$isStart)return
FALSE;$el=TexyHtml::el($mTag);if(!$isStart){if(is_callable(array($tx->handler,'htmlTag'))){$res=$tx->handler->htmlTag($parser,$el,FALSE);if($res!==Texy::PROCEED)return$res;}return$this->solveTag($el,FALSE);}$matches2=NULL;preg_match_all('#([a-z0-9:-]+)\s*(?:=\s*(\'[^\']*\'|"[^"]*"|[^\'"\s]+))?()#isu',$mAttr,$matches2,PREG_SET_ORDER);foreach($matches2
as$m){$key=strtolower($m[1]);$val=$m[2];if($val==NULL)$el->attrs[$key]=TRUE;elseif($val{0}==='\''||$val{0}==='"')$el->attrs[$key]=Texy::unescapeHtml(substr($val,1,-1));else$el->attrs[$key]=Texy::unescapeHtml($val);}if(is_callable(array($tx->handler,'htmlTag'))){$res=$tx->handler->htmlTag($parser,$el,TRUE,$isEmpty);if($res!==Texy::PROCEED)return$res;}return$this->solveTag($el,TRUE,$isEmpty);}public
function
solveTag(TexyHtml$el,$isStart,$forceEmpty=NULL){$tx=$this->texy;$aTags=$tx->allowedTags;if(!$aTags){return
FALSE;}elseif(is_array($aTags)){if(!isset($aTags[$el->name])){$el->setName(strtolower($el->name));if(!isset($aTags[$el->name]))return
FALSE;}$aAttrs=$aTags[$el->name];}else{if($el->name===strtoupper($el->name))$el->setName(strtolower($el->name));$aAttrs=Texy::ALL;}if($forceEmpty&&$aTags===Texy::ALL)$el->isEmpty=TRUE;if(!$isStart){return$tx->protect($el->endTag(),$el->getContentType());}$elAttrs=&$el->attrs;if(!$aAttrs){$elAttrs=array();}elseif(is_array($aAttrs)){$aAttrs=array_flip($aAttrs);foreach($elAttrs
as$key=>$foo)if(!isset($aAttrs[$key]))unset($elAttrs[$key]);}$tmp=$tx->_classes;if(isset($elAttrs['class'])){if(is_array($tmp)){$elAttrs['class']=explode(' ',$elAttrs['class']);foreach($elAttrs['class']as$key=>$val)if(!isset($tmp[$val]))unset($elAttrs['class'][$key]);}elseif($tmp!==Texy::ALL){$elAttrs['class']=NULL;}}if(isset($elAttrs['id'])){if(is_array($tmp)){if(!isset($tmp['#'.$elAttrs['id']]))$elAttrs['id']=NULL;}elseif($tmp!==Texy::ALL){$elAttrs['id']=NULL;}}if(isset($elAttrs['style'])){$tmp=$tx->_styles;if(is_array($tmp)){$styles=explode(';',$elAttrs['style']);$elAttrs['style']=NULL;foreach($styles
as$value){$pair=explode(':',$value,2);$prop=trim($pair[0]);if(isset($pair[1])&&isset($tmp[strtolower($prop)]))$elAttrs['style'][$prop]=$pair[1];}}elseif($tmp!==Texy::ALL){$elAttrs['style']=NULL;}}if($el->name==='img'){if(!isset($elAttrs['src']))return
FALSE;if(!$tx->checkURL($elAttrs['src'],'i'))return
FALSE;$tx->summary['images'][]=$elAttrs['src'];}elseif($el->name==='a'){if(!isset($elAttrs['href'])&&!isset($elAttrs['name'])&&!isset($elAttrs['id']))return
FALSE;if(isset($elAttrs['href'])){if($tx->linkModule->forceNoFollow&&strpos($elAttrs['href'],'//')!==FALSE){if(isset($elAttrs['rel']))$elAttrs['rel']=(array)$elAttrs['rel'];$elAttrs['rel'][]='nofollow';}if(!$tx->checkURL($elAttrs['href'],'a'))return
FALSE;$tx->summary['links'][]=$elAttrs['href'];}}return$tx->protect($el->startTag(),$el->getContentType());}public
function
solveComment($content){if(!$this->passComment)return'';$content=preg_replace('#-{2,}#','-',$content);$content=rtrim($content,'-');return$this->texy->protect('<!--'.$content.'-->',Texy::CONTENT_MARKUP);}}

class
TexyFigureModule
extends
TexyModule{protected$syntax=array('figure'=>TRUE);public$class='figure';public$leftClass;public$rightClass;public$widthDelta=10;public
function
begin(){$this->texy->registerBlockPattern(array($this,'pattern'),'#^'.TEXY_IMAGE.TEXY_LINK_N.'?? +\*\*\* +(.*)'.TEXY_MODIFIER_H.'?()$#mUu','figure');}public
function
pattern($parser,$matches){list(,$mURLs,$mImgMod,$mAlign,$mLink,$mContent,$mMod)=$matches;$tx=$this->texy;$image=$tx->imageModule->factoryImage($mURLs,$mImgMod.$mAlign);$mod=new
TexyModifier($mMod);$mContent=ltrim($mContent);if($mLink){if($mLink===':'){$link=new
TexyLink($image->linkedURL===NULL?$image->URL:$image->linkedURL);$link->raw=':';$link->type=TexyLink::IMAGE;}else{$link=$tx->linkModule->factoryLink($mLink,NULL,NULL);}}else$link=NULL;if(is_callable(array($tx->handler,'figure'))){$res=$tx->handler->figure($parser,$image,$link,$mContent,$mod);if($res!==Texy::PROCEED)return$res;}return$this->solve($image,$link,$mContent,$mod);}public
function
solve(TexyImage$image,$link,$content,$mod){$tx=$this->texy;$hAlign=$image->modifier->hAlign;$mod->hAlign=$image->modifier->hAlign=NULL;$elImg=$tx->imageModule->solve($image,$link);if(!$elImg)return
FALSE;$el=TexyHtml::el('div');if(!empty($image->width))$el->attrs['style']['width']=($image->width+$this->widthDelta).'px';$mod->decorate($tx,$el);$el->children['img']=$elImg;$el->children['caption']=TexyHtml::el('p');$el->children['caption']->parseLine($tx,ltrim($content));if($hAlign===TexyModifier::HALIGN_LEFT){if($this->leftClass!='')$el->attrs['class'][]=$this->leftClass;else$el->attrs['style']['float']='left';}elseif($hAlign===TexyModifier::HALIGN_RIGHT){if($this->rightClass!='')$el->attrs['class'][]=$this->rightClass;else$el->attrs['style']['float']='right';}elseif($this->class)$el->attrs['class'][]=$this->class;return$el;}}

class
TexyImageModule
extends
TexyModule
implements
ITexyPreBlock{protected$syntax=array('image'=>TRUE,'image/definition'=>TRUE,);public$root='images/';public$linkedRoot='images/';public$fileRoot='images/';public$leftClass;public$rightClass;public$defaultAlt='';public$onLoad="var i=new Image();i.src='%i';if(typeof preload=='undefined')preload=new Array();preload[preload.length]=i;this.onload=''";private$references=array();public
function
__construct($texy){parent::__construct($texy);if(isset($_SERVER['SCRIPT_FILENAME'])){$this->fileRoot=dirname($_SERVER['SCRIPT_FILENAME']).'/'.$this->root;}}public
function
begin(){$this->texy->registerLinePattern(array($this,'patternImage'),'#'.TEXY_IMAGE.TEXY_LINK_N.'??()#Uu','image');}public
function
preBlock($text,$topLevel){if($topLevel&&$this->texy->allowed['image/definition'])$text=preg_replace_callback('#^\[\*([^\n]+)\*\]:\ +(.+)\ *'.TEXY_MODIFIER.'?\s*()$#mUu',array($this,'patternReferenceDef'),$text);return$text;}public
function
patternReferenceDef($matches){list(,$mRef,$mURLs,$mMod)=$matches;$image=$this->factoryImage($mURLs,$mMod,FALSE);$this->addReference($mRef,$image);return'';}public
function
patternImage($parser,$matches){list(,$mURLs,$mMod,$mAlign,$mLink)=$matches;$tx=$this->texy;$image=$this->factoryImage($mURLs,$mMod.$mAlign);if($mLink){if($mLink===':'){$link=new
TexyLink($image->linkedURL===NULL?$image->URL:$image->linkedURL);$link->raw=':';$link->type=TexyLink::IMAGE;}else{$link=$tx->linkModule->factoryLink($mLink,NULL,NULL);}}else$link=NULL;if(is_callable(array($tx->handler,'image'))){$res=$tx->handler->image($parser,$image,$link);if($res!==Texy::PROCEED)return$res;}return$this->solve($image,$link);}public
function
addReference($name,TexyImage$image){$image->name=TexyUtf::strtolower($name);$this->references[$image->name]=$image;}public
function
getReference($name){$name=TexyUtf::strtolower($name);if(isset($this->references[$name]))return
clone$this->references[$name];return
FALSE;}public
function
factoryImage($content,$mod,$tryRef=TRUE){$image=$tryRef?$this->getReference(trim($content)):FALSE;if(!$image){$tx=$this->texy;$content=explode('|',$content);$image=new
TexyImage;$matches=NULL;if(preg_match('#^(.*) (?:(\d+)|\?) *x *(?:(\d+)|\?) *()$#U',$content[0],$matches)){$image->URL=trim($matches[1]);$image->width=(int)$matches[2];$image->height=(int)$matches[3];}else{$image->URL=trim($content[0]);}if(!$tx->checkURL($image->URL,'i'))$image->URL=NULL;if(isset($content[1])){$tmp=trim($content[1]);if($tmp!==''&&$tx->checkURL($tmp,'i'))$image->overURL=$tmp;}if(isset($content[2])){$tmp=trim($content[2]);if($tmp!==''&&$tx->checkURL($tmp,'a'))$image->linkedURL=$tmp;}}$image->modifier->setProperties($mod);return$image;}public
function
solve(TexyImage$image,$link){if($image->URL==NULL)return
FALSE;$tx=$this->texy;$mod=$image->modifier;$alt=$mod->title;$mod->title=NULL;$hAlign=$mod->hAlign;$mod->hAlign=NULL;$el=TexyHtml::el('img');$el->attrs['src']=NULL;$mod->decorate($tx,$el);$el->attrs['src']=Texy::prependRoot($image->URL,$this->root);if(!isset($el->attrs['alt'])){if($alt!==NULL)$el->attrs['alt']=$tx->typographyModule->postLine($alt);else$el->attrs['alt']=$this->defaultAlt;}if($hAlign===TexyModifier::HALIGN_LEFT){if($this->leftClass!='')$el->attrs['class'][]=$this->leftClass;else$el->attrs['style']['float']='left';}elseif($hAlign===TexyModifier::HALIGN_RIGHT){if($this->rightClass!='')$el->attrs['class'][]=$this->rightClass;else$el->attrs['style']['float']='right';}if($image->width||$image->height){$el->attrs['width']=$image->width;$el->attrs['height']=$image->height;}else{if(Texy::isRelative($image->URL)&&strpos($image->URL,'..')===FALSE){$file=rtrim($this->fileRoot,'/\\').'/'.$image->URL;if(is_file($file)){$size=getImageSize($file);if(is_array($size)){$image->width=$el->attrs['width']=$size[0];$image->height=$el->attrs['height']=$size[1];}}}}if($image->overURL!==NULL){$overSrc=Texy::prependRoot($image->overURL,$this->root);$el->attrs['onmouseover']='this.src=\''.addSlashes($overSrc).'\'';$el->attrs['onmouseout']='this.src=\''.addSlashes($el->attrs['src']).'\'';$el->attrs['onload']=str_replace('%i',addSlashes($overSrc),$this->onLoad);$tx->summary['preload'][]=$overSrc;}$tx->summary['images'][]=$el->attrs['src'];if($link)return$tx->linkModule->solve($link,$el);return$el;}}class
TexyImage{public$URL;public$overURL;public$linkedURL;public$width;public$height;public$modifier;public$name;public
function
__construct(){$this->modifier=new
TexyModifier;}public
function
__clone(){if($this->modifier)$this->modifier=clone$this->modifier;}function
__get($nm){throw
new
Exception("Undefined property '".get_class($this)."::$$nm'");}function
__set($nm,$val){$this->__get($nm);}}

class
TexyLinkModule
extends
TexyModule
implements
ITexyPreBlock{protected$syntax=array('link/reference'=>TRUE,'link/email'=>TRUE,'link/url'=>TRUE,'link/definition'=>TRUE,);public$root='';public$imageOnClick='return !popupImage(this.href)';public$popupOnClick='return !popup(this.href)';public$forceNoFollow=FALSE;protected$references=array();static
private$deadlock;public
function
begin(){self::$deadlock=array();$tx=$this->texy;$tx->registerLinePattern(array($this,'patternReference'),'#(\[[^\[\]\*\n'.TEXY_MARK.']+\])#U','link/reference');$tx->registerLinePattern(array($this,'patternUrlEmail'),'#(?<=^|[\s(\[<:])(?:https?://|www\.|ftp://)[a-z0-9.-][/a-z\d+\.~%&?@=_:;\#,-]+[/\w\d+~%?@=_\#]#iu','link/url');$tx->registerLinePattern(array($this,'patternUrlEmail'),'#(?<=^|[\s(\[\<:])'.TEXY_EMAIL.'#iu','link/email');}public
function
preBlock($text,$topLevel){if($topLevel&&$this->texy->allowed['link/definition'])$text=preg_replace_callback('#^\[([^\[\]\#\?\*\n]+)\]: +(\S+)(\ .+)?'.TEXY_MODIFIER.'?\s*()$#mUu',array($this,'patternReferenceDef'),$text);return$text;}private
function
patternReferenceDef($matches){list(,$mRef,$mLink,$mLabel,$mMod)=$matches;$link=new
TexyLink($mLink);$link->label=trim($mLabel);$link->modifier->setProperties($mMod);$this->checkLink($link);$this->addReference($mRef,$link);return'';}public
function
patternReference($parser,$matches){list(,$mRef)=$matches;$tx=$this->texy;$name=substr($mRef,1,-1);$link=$this->getReference($name);if(!$link){if(is_callable(array($tx->handler,'newReference'))){$res=$tx->handler->newReference($parser,$name);if($res!==Texy::PROCEED)return$res;}return
FALSE;}$link->type=TexyLink::BRACKET;if($link->label!=''){if(isset(self::$deadlock[$link->name])){$content=$link->label;}else{self::$deadlock[$link->name]=TRUE;$lineParser=new
TexyLineParser($tx);$content=$lineParser->parse($link->label);unset(self::$deadlock[$link->name]);}}else{$content=$this->textualURL($link);}if(is_callable(array($tx->handler,'linkReference'))){$res=$tx->handler->linkReference($parser,$link,$content);if($res!==Texy::PROCEED)return$res;}return$this->solve($link,$content);}public
function
patternUrlEmail($parser,$matches,$name){list($mURL)=$matches;$link=new
TexyLink($mURL);$this->checkLink($link);$content=$this->textualURL($link);$method=$name==='link/email'?'linkEmail':'linkURL';if(is_callable(array($this->texy->handler,$method))){$res=$this->texy->handler->$method($parser,$link,$content);if($res!==Texy::PROCEED)return$res;}return$this->solve($link,$content);}public
function
addReference($name,TexyLink$link){$link->name=TexyUtf::strtolower($name);$this->references[$link->name]=$link;}public
function
getReference($name){$name=TexyUtf::strtolower($name);if(isset($this->references[$name])){return
clone$this->references[$name];}else{$pos=strpos($name,'?');if($pos===FALSE)$pos=strpos($name,'#');if($pos!==FALSE){$name2=substr($name,0,$pos);if(isset($this->references[$name2])){$link=clone$this->references[$name2];$link->URL.=substr($name,$pos);return$link;}}}return
FALSE;}public
function
factoryLink($dest,$mMod,$label){$tx=$this->texy;$type=TexyLink::COMMON;if(strlen($dest)>1&&$dest{0}==='['&&$dest{1}!=='*'){$type=TexyLink::BRACKET;$dest=substr($dest,1,-1);$link=$this->getReference($dest);}elseif(strlen($dest)>1&&$dest{0}==='['&&$dest{1}==='*'){$type=TexyLink::IMAGE;$dest=trim(substr($dest,2,-2));$image=$tx->imageModule->getReference($dest);if($image){$link=new
TexyLink($image->linkedURL===NULL?$image->URL:$image->linkedURL);$link->modifier=$image->modifier;}}if(empty($link)){$link=new
TexyLink(trim($dest));$this->checkLink($link);}if(strpos($link->URL,'%s')!==FALSE){$link->URL=str_replace('%s',urlencode($tx->_toText($label)),$link->URL);}$link->modifier->setProperties($mMod);$link->type=$type;return$link;}public
function
solve($link,$content=NULL){if($link->URL==NULL)return$content;$tx=$this->texy;$el=TexyHtml::el('a');if(empty($link->modifier)){$nofollow=$popup=FALSE;}else{$classes=array_flip($link->modifier->classes);$nofollow=isset($classes['nofollow']);$popup=isset($classes['popup']);unset($classes['nofollow'],$classes['popup']);$link->modifier->classes=array_flip($classes);$el->attrs['href']=NULL;$link->modifier->decorate($tx,$el);}if($link->type===TexyLink::IMAGE){$el->attrs['href']=Texy::prependRoot($link->URL,$tx->imageModule->linkedRoot);$el->attrs['onclick']=$this->imageOnClick;}else{$el->attrs['href']=Texy::prependRoot($link->URL,$this->root);if($nofollow||($this->forceNoFollow&&strpos($el->attrs['href'],'//')!==FALSE))$el->attrs['rel']='nofollow';}if($popup)$el->attrs['onclick']=$this->popupOnClick;if($content!==NULL){if($content
instanceof
TexyHtml)$el->addChild($content);else$el->setText($content);}$tx->summary['links'][]=$el->attrs['href'];return$el;}private
function
checkLink($link){$link->raw=$link->URL;if(strncasecmp($link->URL,'www.',4)===0){$link->URL='http://'.$link->URL;}elseif(preg_match('#'.TEXY_EMAIL.'$#iA',$link->URL)){$link->URL='mailto:'.$link->URL;}elseif(!$this->texy->checkURL($link->URL,'a')){$link->URL=NULL;}else{$link->URL=str_replace('&amp;','&',$link->URL);}}private
function
textualURL($link){$URL=$link->raw===NULL?$link->URL:$link->raw;if(preg_match('#^'.TEXY_EMAIL.'$#i',$URL)){return$this->texy->obfuscateEmail?str_replace('@',$this->texy->protect("&#64;<!---->",Texy::CONTENT_MARKUP),$URL):$URL;}if(preg_match('#^(https?://|ftp://|www\.|/)#i',$URL)){if(strncasecmp($URL,'www.',4)===0)$parts=@parse_url('none://'.$URL);else$parts=@parse_url($URL);if($parts===FALSE)return$URL;$res='';if(isset($parts['scheme'])&&$parts['scheme']!=='none')$res.=$parts['scheme'].'://';if(isset($parts['host']))$res.=$parts['host'];if(isset($parts['path']))$res.=(strlen($parts['path'])>16?('/...'.preg_replace('#^.*(.{0,12})$#U','$1',$parts['path'])):$parts['path']);if(isset($parts['query'])){$res.=strlen($parts['query'])>4?'?...':('?'.$parts['query']);}elseif(isset($parts['fragment'])){$res.=strlen($parts['fragment'])>4?'#...':('#'.$parts['fragment']);}return$res;}return$URL;}}class
TexyLink{const
COMMON=1,BRACKET=2,IMAGE=3;public$URL;public$raw;public$modifier;public$type=TexyLink::COMMON;public$label;public$name;public
function
__construct($URL){$this->URL=$URL;$this->modifier=new
TexyModifier;}public
function
__clone(){if($this->modifier)$this->modifier=clone$this->modifier;}function
__get($nm){throw
new
Exception("Undefined property '".get_class($this)."::$$nm'");}function
__set($nm,$val){$this->__get($nm);}}

class
TexyListModule
extends
TexyModule{protected$syntax=array('list'=>TRUE,'list/definition'=>TRUE);public$bullets=array('*'=>array('\*\ ',0,''),'-'=>array('[\x{2013}-](?![>-])',0,''),'+'=>array('\+\ ',0,''),'1.'=>array('1\.\ ',1,'','\d{1,3}\.\ '),'1)'=>array('\d{1,3}\)\ ',1,''),'I.'=>array('I\.\ ',1,'upper-roman','[IVX]{1,4}\.\ '),'I)'=>array('[IVX]+\)\ ',1,'upper-roman'),'a)'=>array('[a-z]\)\ ',1,'lower-alpha'),'A)'=>array('[A-Z]\)\ ',1,'upper-alpha'),);public
function
begin(){$RE=$REul=array();foreach($this->bullets
as$desc){$RE[]=$desc[0];if(!$desc[1])$REul[]=$desc[0];}$this->texy->registerBlockPattern(array($this,'patternList'),'#^(?:'.TEXY_MODIFIER_H.'\n)?'.'('.implode('|',$RE).')\ *\S.*$#mUu','list');$this->texy->registerBlockPattern(array($this,'patternDefList'),'#^(?:'.TEXY_MODIFIER_H.'\n)?'.'(\S.*)\:\ *'.TEXY_MODIFIER_H.'?\n'.'(\ ++)('.implode('|',$REul).')\ *\S.*$#mUu','list/definition');}public
function
patternList($parser,$matches){list(,$mMod,$mBullet)=$matches;$tx=$this->texy;$el=TexyHtml::el();$bullet=$min=NULL;foreach($this->bullets
as$type=>$desc)if(preg_match('#'.$desc[0].'#Au',$mBullet)){$bullet=isset($desc[3])?$desc[3]:$desc[0];$min=isset($desc[3])?2:1;$el->name=$desc[1]?'ol':'ul';$el->attrs['style']['list-style-type']=$desc[2];if($desc[1]){if($type[0]==='1'&&(int)$mBullet>1)$el->attrs['start']=(int)$mBullet;elseif($type[0]==='a'&&$mBullet[0]>'a')$el->attrs['start']=ord($mBullet[0])-96;elseif($type[0]==='A'&&$mBullet[0]>'A')$el->attrs['start']=ord($mBullet[0])-64;}break;}$mod=new
TexyModifier($mMod);$mod->decorate($tx,$el);$parser->moveBackward(1);while($elItem=$this->patternItem($parser,$bullet,FALSE,'li'))$el->addChild($elItem);if(count($el->children)<$min)return
FALSE;if(is_callable(array($tx->handler,'afterList')))$tx->handler->afterList($parser,$el,$mod);return$el;}public
function
patternDefList($parser,$matches){list(,$mMod,,,,$mBullet)=$matches;$tx=$this->texy;$bullet=NULL;foreach($this->bullets
as$type=>$desc)if(preg_match('#'.$desc[0].'#Au',$mBullet)){$bullet=isset($desc[3])?$desc[3]:$desc[0];break;}$el=TexyHtml::el('dl');$mod=new
TexyModifier($mMod);$mod->decorate($tx,$el);$parser->moveBackward(2);$patternTerm='#^\n?(\S.*)\:\ *'.TEXY_MODIFIER_H.'?()$#mUA';while(TRUE){if($elItem=$this->patternItem($parser,$bullet,TRUE,'dd')){$el->addChild($elItem);continue;}if($parser->next($patternTerm,$matches)){list(,$mContent,$mMod)=$matches;$elItem=TexyHtml::el('dt');$mod=new
TexyModifier($mMod);$mod->decorate($tx,$elItem);$elItem->parseLine($tx,$mContent);$el->addChild($elItem);continue;}break;}if(is_callable(array($tx->handler,'afterDefinitionList')))$tx->handler->afterDefinitionList($parser,$el,$mod);return$el;}public
function
patternItem($parser,$bullet,$indented,$tag){$tx=$this->texy;$spacesBase=$indented?('\ {1,}'):'';$patternItem="#^\n?($spacesBase)$bullet\\ *(\\S.*)?".TEXY_MODIFIER_H."?()$#mAUu";$matches=NULL;if(!$parser->next($patternItem,$matches))return
FALSE;list(,$mIndent,$mContent,$mMod)=$matches;$elItem=TexyHtml::el($tag);$mod=new
TexyModifier($mMod);$mod->decorate($tx,$elItem);$spaces='';$content=' '.$mContent;while($parser->next('#^(\n*)'.$mIndent.'(\ {1,'.$spaces.'})(.*)()$#Am',$matches)){list(,$mBlank,$mSpaces,$mContent)=$matches;if($spaces==='')$spaces=strlen($mSpaces);$content.="\n".$mBlank.$mContent;}$tmp=$tx->paragraphModule->mode;$tx->paragraphModule->mode=FALSE;$elItem->parseBlock($tx,$content);$tx->paragraphModule->mode=$tmp;if($elItem->getChild(0)instanceof
TexyHtml){$elItem->getChild(0)->setName(NULL);}return$elItem;}}

class
TexyLongWordsModule
extends
TexyModule
implements
ITexyPostLine{protected$syntax=array('longwords'=>TRUE);public$wordLimit=20;const
DONT=0,HERE=1,AFTER=2;private$consonants=array('b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','z','B','C','D','F','G','H','J','K','L','M','N','P','Q','R','S','T','V','W','X','Z',"\xc4\x8d","\xc4\x8f","\xc5\x88","\xc5\x99","\xc5\xa1","\xc5\xa5","\xc5\xbe","\xc4\x8c","\xc4\x8e","\xc5\x87","\xc5\x98","\xc5\xa0","\xc5\xa4","\xc5\xbd");private$vowels=array('a','e','i','o','u','y','A','E','I','O','U','Y',"\xc3\xa1","\xc3\xa9","\xc4\x9b","\xc3\xad","\xc3\xb3","\xc3\xba","\xc5\xaf","\xc3\xbd","\xc3\x81","\xc3\x89","\xc4\x9a","\xc3\x8d","\xc3\x93","\xc3\x9a","\xc5\xae","\xc3\x9d");private$before_r=array('b','B','c','C','d','D','f','F','g','G','k','K','p','P','r','R','t','T','v','V',"\xc4\x8d","\xc4\x8c","\xc4\x8f","\xc4\x8e","\xc5\x99","\xc5\x98","\xc5\xa5","\xc5\xa4");private$before_l=array('b','B','c','C','d','D','f','F','g','G','k','K','l','L','p','P','t','T','v','V',"\xc4\x8d","\xc4\x8c","\xc4\x8f","\xc4\x8e","\xc5\xa5","\xc5\xa4");private$before_h=array('c','C','s','S');private$doubleVowels=array('a','A','o','O');public
function
__construct($texy){parent::__construct($texy);$this->consonants=array_flip($this->consonants);$this->vowels=array_flip($this->vowels);$this->before_r=array_flip($this->before_r);$this->before_l=array_flip($this->before_l);$this->before_h=array_flip($this->before_h);$this->doubleVowels=array_flip($this->doubleVowels);}public
function
postLine($text){if(empty($this->texy->allowed['longwords']))return$text;return
preg_replace_callback('#[^\ \n\t\x14\x15\x16\x{2013}\x{2014}\x{ad}-]{'.$this->wordLimit.',}#u',array($this,'pattern'),$text);}private
function
pattern($matches){list($mWord)=$matches;$chars=array();preg_match_all('#['.TEXY_MARK.']+|.#u',$mWord,$chars);$chars=$chars[0];if(count($chars)<$this->wordLimit)return$mWord;$consonants=$this->consonants;$vowels=$this->vowels;$before_r=$this->before_r;$before_l=$this->before_l;$before_h=$this->before_h;$doubleVowels=$this->doubleVowels;$s=array();$trans=array();$s[]='';$trans[]=-1;foreach($chars
as$key=>$char){if(ord($char{0})<32)continue;$s[]=$char;$trans[]=$key;}$s[]='';$len=count($s)-2;$positions=array();$a=0;$last=1;while(++$a<$len){$hyphen=self::DONT;do{if($s[$a]==="\xC2\xA0"){$a++;continue
2;}if($s[$a]==='.'){$hyphen=self::HERE;break;}if(isset($consonants[$s[$a]])){if(isset($vowels[$s[$a+1]])){if(isset($vowels[$s[$a-1]]))$hyphen=self::HERE;break;}if(($s[$a]==='s')&&($s[$a-1]==='n')&&isset($consonants[$s[$a+1]])){$hyphen=self::AFTER;break;}if(isset($consonants[$s[$a+1]])&&isset($vowels[$s[$a-1]])){if($s[$a+1]==='r'){$hyphen=isset($before_r[$s[$a]])?self::HERE:self::AFTER;break;}if($s[$a+1]==='l'){$hyphen=isset($before_l[$s[$a]])?self::HERE:self::AFTER;break;}if($s[$a+1]==='h'){$hyphen=isset($before_h[$s[$a]])?self::DONT:self::AFTER;break;}$hyphen=self::AFTER;break;}break;}if(($s[$a]==='u')&&isset($doubleVowels[$s[$a-1]])){$hyphen=self::AFTER;break;}if(isset($vowels[$s[$a]])&&isset($vowels[$s[$a-1]])){$hyphen=self::HERE;break;}}while(0);if($hyphen===self::DONT&&($a-$last>$this->wordLimit*0.6))$positions[]=$last=$a-1;if($hyphen===self::HERE)$positions[]=$last=$a-1;if($hyphen===self::AFTER){$positions[]=$last=$a;$a++;}}$a=end($positions);if(($a===$len-1)&&isset($consonants[$s[$len]]))array_pop($positions);$syllables=array();$last=0;foreach($positions
as$pos){if($pos-$last>$this->wordLimit*0.6){$syllables[]=implode('',array_splice($chars,0,$trans[$pos]-$trans[$last]));$last=$pos;}}$syllables[]=implode('',$chars);return
implode("\xC2\xAD",$syllables);;}}

class
TexyPhraseModule
extends
TexyModule{protected$syntax=array('phrase/strong+em'=>TRUE,'phrase/strong'=>TRUE,'phrase/em'=>TRUE,'phrase/em-alt'=>TRUE,'phrase/span'=>TRUE,'phrase/span-alt'=>TRUE,'phrase/acronym'=>TRUE,'phrase/acronym-alt'=>TRUE,'phrase/code'=>TRUE,'phrase/notexy'=>TRUE,'phrase/quote'=>TRUE,'phrase/quicklink'=>TRUE,'phrase/sup-alt'=>TRUE,'phrase/sub-alt'=>TRUE,'phrase/ins'=>FALSE,'phrase/del'=>FALSE,'phrase/sup'=>FALSE,'phrase/sub'=>FALSE,'phrase/cite'=>FALSE,'deprecated/codeswitch'=>FALSE,);public$tags=array('phrase/strong'=>'strong','phrase/em'=>'em','phrase/em-alt'=>'em','phrase/ins'=>'ins','phrase/del'=>'del','phrase/sup'=>'sup','phrase/sup-alt'=>'sup','phrase/sub'=>'sub','phrase/sub-alt'=>'sub','phrase/span'=>'a','phrase/span-alt'=>'a','phrase/cite'=>'cite','phrase/acronym'=>'acronym','phrase/acronym-alt'=>'acronym','phrase/code'=>'code','phrase/quote'=>'q','phrase/quicklink'=>'a',);public$linksAllowed=TRUE;public
function
begin(){$tx=$this->texy;$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\*)\*\*\*(?![\s*])(.+)'.TEXY_MODIFIER.'?(?<![\s*])\*\*\*(?!\*)'.TEXY_LINK.'??()#Uus','phrase/strong+em');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\*)\*\*(?![\s*])(.+)'.TEXY_MODIFIER.'?(?<![\s*])\*\*(?!\*)'.TEXY_LINK.'??()#Uus','phrase/strong');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<![/:])\/\/(?![\s/])(.+)'.TEXY_MODIFIER.'?(?<![\s/])\/\/(?!\/)'.TEXY_LINK.'??()#Uus','phrase/em');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\*)\*(?![\s*])(.+)'.TEXY_MODIFIER.'?(?<![\s*])\*(?!\*)'.TEXY_LINK.'??()#Uus','phrase/em-alt');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\+)\+\+(?![\s+])([^\r\n]+)'.TEXY_MODIFIER.'?(?<![\s+])\+\+(?!\+)()#Uu','phrase/ins');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<![<-])\-\-(?![\s>-])([^\r\n]+)'.TEXY_MODIFIER.'?(?<![\s<-])\-\-(?![>-])()#Uu','phrase/del');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\^)\^\^(?![\s^])([^\r\n]+)'.TEXY_MODIFIER.'?(?<![\s^])\^\^(?!\^)()#Uu','phrase/sup');$tx->registerLinePattern(array($this,'patternSupSub'),'#(?<=[a-z0-9])\^([0-9]{1,4})(?![a-z0-9])#Uui','phrase/sup-alt');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\_)\_\_(?![\s_])([^\r\n]+)'.TEXY_MODIFIER.'?(?<![\s_])\_\_(?!\_)()#Uu','phrase/sub');$tx->registerLinePattern(array($this,'patternSupSub'),'#(?<=[a-z])\_([0-9]{1,3})(?![a-z0-9])#Uui','phrase/sub-alt');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\")\"(?!\s)([^\"\r]+)'.TEXY_MODIFIER.'?(?<!\s)\"(?!\")'.TEXY_LINK.'??()#Uu','phrase/span');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\~)\~(?!\s)([^\~\r]+)'.TEXY_MODIFIER.'?(?<!\s)\~(?!\~)'.TEXY_LINK.'??()#Uu','phrase/span-alt');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\~)\~\~(?![\s~])([^\r\n]+)'.TEXY_MODIFIER.'?(?<![\s~])\~\~(?!\~)'.TEXY_LINK.'??()#Uu','phrase/cite');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\>)\>\>(?![\s>])([^\r\n]+)'.TEXY_MODIFIER.'?(?<![\s<])\<\<(?!\<)'.TEXY_LINK.'??()#Uu','phrase/quote');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!\")\"(?!\s)([^\"\r\n]+)'.TEXY_MODIFIER.'?(?<!\s)\"(?!\")\(\((.+)\)\)()#Uu','phrase/acronym');$tx->registerLinePattern(array($this,'patternPhrase'),'#(?<!['.TEXY_CHAR.'])(['.TEXY_CHAR.']{2,})()\(\((.+)\)\)#Uu','phrase/acronym-alt');$tx->registerLinePattern(array($this,'patternNoTexy'),'#(?<!\')\'\'(?![\s\'])([^'.TEXY_MARK.'\r\n]*)(?<![\s\'])\'\'(?!\')()#Uu','phrase/notexy');$tx->registerLinePattern(array($this,'patternPhrase'),'#\`(\S[^'.TEXY_MARK.'\r\n]*)'.TEXY_MODIFIER.'?(?<!\s)\`'.TEXY_LINK.'??()#Uu','phrase/code');$tx->registerLinePattern(array($this,'patternPhrase'),'#(['.TEXY_CHAR.'0-9@\#$%&.,_-]+)()(?=:\[)'.TEXY_LINK.'()#Uu','phrase/quicklink');$tx->registerBlockPattern(array($this,'patternCodeSwitch'),'#^`=(none|code|kbd|samp|var|span)$#mUi','deprecated/codeswitch');}public
function
patternPhrase($parser,$matches,$phrase){list(,$mContent,$mMod,$mLink)=$matches;$tx=$this->texy;$mod=new
TexyModifier($mMod);$link=NULL;$parser->again=$phrase!=='phrase/code'&&$phrase!=='phrase/quicklink';if($phrase==='phrase/span'||$phrase==='phrase/span-alt'){if($mLink==NULL){if(!$mMod)return
FALSE;}else{$link=$tx->linkModule->factoryLink($mLink,$mMod,$mContent);}}elseif($phrase==='phrase/acronym'||$phrase==='phrase/acronym-alt'){$mod->title=trim(Texy::unescapeHtml($mLink));}elseif($phrase==='phrase/quote'){$mod->cite=$tx->quoteModule->citeLink($mLink);}elseif($mLink!=NULL){$link=$tx->linkModule->factoryLink($mLink,NULL,$mContent);}if(is_callable(array($tx->handler,'phrase'))){$res=$tx->handler->phrase($parser,$phrase,$mContent,$mod,$link);if($res!==Texy::PROCEED)return$res;}return$this->solve($phrase,$mContent,$mod,$link);}public
function
patternSupSub($parser,$matches,$phrase){list(,$mContent)=$matches;$mod=new
TexyModifier();$link=NULL;if(is_callable(array($this->texy->handler,'phrase'))){$res=$this->texy->handler->phrase($parser,$phrase,$mContent,$mod,$link);if($res!==Texy::PROCEED)return$res;}return$this->solve($phrase,$mContent,$mod,$link);}public
function
solve($phrase,$content,$mod,$link){$tx=$this->texy;$tag=isset($this->tags[$phrase])?$this->tags[$phrase]:NULL;if($tag==='a')$tag=$link&&$this->linksAllowed?NULL:'span';if($phrase==='phrase/code')$content=$tx->protect(Texy::escapeHtml($content),Texy::CONTENT_TEXTUAL);if($phrase==='phrase/strong+em'){$el=TexyHtml::el($this->tags['phrase/strong']);$el->add($this->tags['phrase/em'],$content);$mod->decorate($tx,$el);}elseif($tag){$el=TexyHtml::el($tag)->setText($content);$mod->decorate($tx,$el);if($tag==='q')$el->attrs['cite']=$mod->cite;}else{$el=$content;}if($link&&$this->linksAllowed)return$tx->linkModule->solve($link,$el);return$el;}public
function
patternNoTexy($parser,$matches){list(,$mContent)=$matches;return$this->texy->protect(Texy::escapeHtml($mContent),Texy::CONTENT_TEXTUAL);}public
function
patternCodeSwitch($parser,$matches){$this->tags['phrase/code']=$matches[1];return"\n";}}

class
TexyQuoteModule
extends
TexyModule{protected$syntax=array('blockquote'=>TRUE);public
function
begin(){$this->texy->registerBlockPattern(array($this,'pattern'),'#^(?:'.TEXY_MODIFIER_H.'\n)?\>(\ +|:)(\S.*)$#mU','blockquote');}public
function
pattern($parser,$matches){list(,$mMod,$mPrefix,$mContent)=$matches;$tx=$this->texy;$el=TexyHtml::el('blockquote');$mod=new
TexyModifier($mMod);$mod->decorate($tx,$el);$content='';$spaces='';do{if($mPrefix===':'){$mod->cite=$tx->quoteModule->citeLink($mContent);$content.="\n";}else{if($spaces==='')$spaces=max(1,strlen($mPrefix));$content.=$mContent."\n";}if(!$parser->next("#^>(?:|(\\ {1,$spaces}|:)(.*))()$#mA",$matches))break;list(,$mPrefix,$mContent)=$matches;}while(TRUE);$el->attrs['cite']=$mod->cite;$el->parseBlock($tx,$content);if(!count($el->children))return
FALSE;if(is_callable(array($tx->handler,'afterBlockquote')))$tx->handler->afterBlockquote($parser,$el,$mod);return$el;}public
function
citeLink($link){$tx=$this->texy;if($link==NULL)return
NULL;if($link{0}==='['){$link=substr($link,1,-1);$ref=$tx->linkModule->getReference($link);if($ref)return
Texy::prependRoot($ref['URL'],$tx->linkModule->root);}if(!$tx->checkURL($link,'c'))return
NULL;if(strncasecmp($link,'www.',4)===0)return'http://'.$link;return
Texy::prependRoot($link,$tx->linkModule->root);}}

class
TexyScriptModule
extends
TexyModule{protected$syntax=array('script'=>TRUE);public$handler;public$separator=',';public
function
begin(){$this->texy->registerLinePattern(array($this,'pattern'),'#\{\{([^'.TEXY_MARK.']+)\}\}()#U','script');}public
function
pattern($parser,$matches){list(,$mContent)=$matches;$cmd=trim($mContent);if($cmd==='')return
FALSE;$args=$raw=NULL;if(preg_match('#^([a-z_][a-z0-9_-]*)\s*(?:\(([^()]*)\)|:(.*))$#iu',$cmd,$matches)){$cmd=$matches[1];$raw=isset($matches[3])?trim($matches[3]):trim($matches[2]);if($raw==='')$args=array();else$args=preg_split('#\s*'.preg_quote($this->separator,'#').'\s*#u',$raw);}if($this->handler){if(is_callable(array($this->handler,$cmd))){array_unshift($args,$parser);return
call_user_func_array(array($this->handler,$cmd),$args);}if(is_callable($this->handler))return
call_user_func_array($this->handler,array($parser,$cmd,$args,$raw));}if(is_callable(array($this->texy->handler,'script'))){$res=$this->texy->handler->script($parser,$cmd,$args,$raw);if($res!==Texy::PROCEED)return$res;}if($cmd==='texy')return$this->texyHandler($args);return
FALSE;}public
function
texyHandler($args){if(!$args)return
FALSE;switch($args[0]){case'nofollow':$this->texy->linkModule->forceNoFollow=TRUE;break;}return'';}}

class
TexyEmoticonModule
extends
TexyModule{protected$syntax=array('emoticon'=>FALSE);public$icons=array(':-)'=>'smile.gif',':-('=>'sad.gif',';-)'=>'wink.gif',':-D'=>'biggrin.gif','8-O'=>'eek.gif','8-)'=>'cool.gif',':-?'=>'confused.gif',':-x'=>'mad.gif',':-P'=>'razz.gif',':-|'=>'neutral.gif',);public$class;public$root;public$fileRoot;public
function
begin(){if(empty($this->texy->allowed['emoticon']))return;krsort($this->icons);$pattern=array();foreach($this->icons
as$key=>$foo)$pattern[]=preg_quote($key,'#').'+';$this->texy->registerLinePattern(array($this,'pattern'),'#(?<=^|[\\x00-\\x20])('.implode('|',$pattern).')#','emoticon');}public
function
pattern($parser,$matches){$match=$matches[0];$tx=$this->texy;foreach($this->icons
as$emoticon=>$foo){if(strncmp($match,$emoticon,strlen($emoticon))===0){if(is_callable(array($tx->handler,'emoticon'))){$res=$tx->handler->emoticon($parser,$emoticon,$match);if($res!==Texy::PROCEED)return$res;}return$this->solve($emoticon,$match);}}return
FALSE;}public
function
solve($emoticon,$raw){$tx=$this->texy;$file=$this->icons[$emoticon];$el=TexyHtml::el('img');$el->attrs['src']=Texy::prependRoot($file,$this->root===NULL?$tx->imageModule->root:$this->root);$el->attrs['alt']=$raw;$el->attrs['class'][]=$this->class;$file=rtrim($this->fileRoot===NULL?$tx->imageModule->fileRoot:$this->fileRoot,'/\\').'/'.$file;if(is_file($file)){$size=getImageSize($file);if(is_array($size)){$el->attrs['width']=$size[0];$el->attrs['height']=$size[1];}}$tx->summary['images'][]=$el->attrs['src'];return$el;}}

class
TexyTableModule
extends
TexyModule{protected$syntax=array('table'=>TRUE);public$oddClass;public$evenClass;private$isHead;private$colModifier;private$last;private$row;public
function
begin(){$this->texy->registerBlockPattern(array($this,'patternTable'),'#^(?:'.TEXY_MODIFIER_HV.'\n)?'.'\|.*()$#mU','table');}public
function
patternTable($parser,$matches){list(,$mMod)=$matches;$tx=$this->texy;$el=TexyHtml::el('table');$mod=new
TexyModifier($mMod);$mod->decorate($tx,$el);$parser->moveBackward();if($parser->next('#^\|(\#|\=){2,}(?!\\1)(.*)\\1*\|? *'.TEXY_MODIFIER_H.'?()$#Um',$matches)){list(,,$mContent,$mMod)=$matches;$caption=$el->add('caption');$mod=new
TexyModifier($mMod);$mod->decorate($tx,$caption);$caption->parseLine($tx,$mContent);}$this->isHead=FALSE;$this->colModifier=array();$this->last=array();$this->row=0;while(TRUE){if($parser->next('#^\|[+-]{3,}$#Um',$matches)){$this->isHead=!$this->isHead;continue;}if($elRow=$this->patternRow($parser)){$el->addChild($elRow);$this->row++;continue;}break;}if(is_callable(array($tx->handler,'afterTable')))$tx->handler->afterTable($parser,$el,$mod);return$el;}protected
function
patternRow($parser){$tx=$this->texy;$matches=NULL;if(!$parser->next('#^\|(.*)(?:|\|\ *'.TEXY_MODIFIER_HV.'?)()$#U',$matches))return
FALSE;list(,$mContent,$mMod)=$matches;$elRow=TexyHtml::el('tr');$mod=new
TexyModifier($mMod);$mod->decorate($tx,$elRow);if($this->row
%
2===0){if($this->oddClass)$elRow->attrs['class'][]=$this->oddClass;}else{if($this->evenClass)$elRow->attrs['class'][]=$this->evenClass;}$col=0;$elField=NULL;$mContent=str_replace('\\|','&#x7C;',$mContent);foreach(explode('|',$mContent)as$field){if(($field=='')&&$elField){$elField->colspan++;unset($this->last[$col]);$col++;continue;}$field=rtrim($field);if($field==='^'){if(isset($this->last[$col])){$this->last[$col]->rowspan++;$col+=$this->last[$col]->colspan;continue;}}if(!preg_match('#(\*??)\ *'.TEXY_MODIFIER_HV.'??(.*)'.TEXY_MODIFIER_HV.'?()$#AU',$field,$matches))continue;list(,$mHead,$mModCol,$mContent,$mMod)=$matches;if($mModCol){$this->colModifier[$col]=new
TexyModifier($mModCol);}if(isset($this->colModifier[$col]))$mod=clone$this->colModifier[$col];else$mod=new
TexyModifier;$mod->setProperties($mMod);$elField=new
TexyTableFieldElement;$elField->setName($this->isHead||($mHead==='*')?'th':'td');$mod->decorate($tx,$elField);$elField->parseLine($tx,$mContent);if($elField->children==='')$elField->children="\xC2\xA0";$elRow->addChild($elField);$this->last[$col]=$elField;$col++;}return$elRow;}}class
TexyTableFieldElement
extends
TexyHtml{public$colspan=1;public$rowspan=1;public
function
startTag(){$this->attrs['colspan']=$this->colspan<2?NULL:$this->colspan;$this->attrs['rowspan']=$this->rowspan<2?NULL:$this->rowspan;return
parent::startTag();}}

class
TexyTypographyModule
extends
TexyModule
implements
ITexyPostLine{protected$syntax=array('typography'=>TRUE);static
public$locales=array('cs'=>array('singleQuotes'=>array("\xe2\x80\x9a","\xe2\x80\x98"),'doubleQuotes'=>array("\xe2\x80\x9e","\xe2\x80\x9c"),),'en'=>array('singleQuotes'=>array("\xe2\x80\x98","\xe2\x80\x99"),'doubleQuotes'=>array("\xe2\x80\x9c","\xe2\x80\x9d"),),'fr'=>array('singleQuotes'=>array("\xe2\x80\xb9","\xe2\x80\xba"),'doubleQuotes'=>array("\xc2\xab","\xc2\xbb"),),'de'=>array('singleQuotes'=>array("\xe2\x80\x9a","\xe2\x80\x98"),'doubleQuotes'=>array("\xe2\x80\x9e","\xe2\x80\x9c"),),'pl'=>array('singleQuotes'=>array("\xe2\x80\x9a","\xe2\x80\x99"),'doubleQuotes'=>array("\xe2\x80\x9e","\xe2\x80\x9d"),),);public$locale='cs';private$pattern,$replace;public
function
begin(){if(isset(self::$locales[$this->locale]))$locale=self::$locales[$this->locale];else$locale=self::$locales['en'];$pairs=array('#(?<![.\x{2026}])\.{3,4}(?![.\x{2026}])#mu'=>"\xe2\x80\xa6",'#(?<=[\d ])-(?=[\d ])#'=>"\xe2\x80\x93",'#,-#'=>",\xe2\x80\x93",'#(?<!\d)(\d{1,2}\.) (\d{1,2}\.) (\d\d)#'=>"\$1\xc2\xa0\$2\xc2\xa0\$3",'#(?<!\d)(\d{1,2}\.) (\d{1,2}\.)#'=>"\$1\xc2\xa0\$2",'#([\x{2013}\x{2014}]) #u'=>"\$1\xc2\xa0",'# --- #'=>" \xe2\x80\x94\xc2\xa0",'# -- #'=>" \xe2\x80\x93\xc2\xa0",'# <-{1,2}> #'=>" \xe2\x86\x94 ",'#-{1,}> #'=>" \xe2\x86\x92 ",'# <-{1,}#'=>" \xe2\x86\x90 ",'#={1,}> #'=>" \xe2\x87\x92 ",'#(\d+)( ?)x\\2(\d+)\\2x\\2(\d+)#'=>"\$1\xc3\x97\$3\xc3\x97\$4",'#(\d+)( ?)x\\2(\d+)#'=>"\$1\xc3\x97\$3",'#(?<=\d)x(?= |,|.|$)#m'=>"\xc3\x97",'#(\S ?)\(TM\)#i'=>"\$1\xe2\x84\xa2",'#(\S ?)\(R\)#i'=>"\$1\xc2\xae",'#\(C\)( ?\S)#i'=>"\xc2\xa9\$1",'#\(EUR\)#'=>"\xe2\x82\xac",'#(\d{1,3}) (\d{3}) (\d{3}) (\d{3})#'=>"\$1\xc2\xa0\$2\xc2\xa0\$3\xc2\xa0\$4",'#(\d{1,3}) (\d{3}) (\d{3})#'=>"\$1\xc2\xa0\$2\xc2\xa0\$3",'#(\d{1,3}) (\d{3})#'=>"\$1\xc2\xa0\$2",'#(?<=[^\s\x17])\s+([\x17-\x1F]+)(?=\s)#u'=>"\$1",'#(?<=\s)([\x17-\x1F]+)\s+#u'=>"\$1",'#(?<=.{50})\s+(?=[\x17-\x1F]*\S{1,6}[\x17-\x1F]*$)#us'=>"\xc2\xa0",'#(?<=^| |\.|,|-|\+|\x16)([\x17-\x1F]*\d+[\x17-\x1F]*)\s+([\x17-\x1F]*['.TEXY_CHAR.'\x{b0}-\x{be}\x{2020}-\x{214f}])#mu'=>"\$1\xc2\xa0\$2",'#(?<=^|[^0-9'.TEXY_CHAR.'])([\x17-\x1F]*[ksvzouiKSVZOUIA][\x17-\x1F]*)\s+([\x17-\x1F]*[0-9'.TEXY_CHAR.'])#mus'=>"\$1\xc2\xa0\$2",'#(?<!"|\w)"(?!\ |")(.+)(?<!\ |")"(?!")()#U'=>$locale['doubleQuotes'][0].'$1'.$locale['doubleQuotes'][1],'#(?<!\'|\w)\'(?!\ |\')(.+)(?<!\ |\')\'(?!\')()#Uu'=>$locale['singleQuotes'][0].'$1'.$locale['singleQuotes'][1],);$this->pattern=array_keys($pairs);$this->replace=array_values($pairs);}public
function
postLine($text){if(empty($this->texy->allowed['typography']))return$text;return
preg_replace($this->pattern,$this->replace,$text);}}
define('TEXY_ALL',TRUE);define('TEXY_NONE',FALSE);define('TEXY_VERSION',Texy::VERSION);define('TEXY_PROCEED',NULL);class
Texy{const
ALL=TRUE;const
NONE=FALSE;const
VERSION='2.0 RC 1 (Revision: 132, Date: 2007/06/08 17:16:44)';const
CONTENT_MARKUP="\x17";const
CONTENT_REPLACED="\x16";const
CONTENT_TEXTUAL="\x15";const
CONTENT_BLOCK="\x14";const
PROCEED=NULL;public$encoding='utf-8';public$allowed=array();public$allowedTags;public$allowedClasses=Texy::ALL;public$allowedStyles=Texy::ALL;public$tabWidth=8;public$obfuscateEmail=TRUE;public$urlSchemeFilters=NULL;public$summary=array('images'=>array(),'links'=>array(),'preload'=>array(),);public$styleSheet='';public$mergeLines=TRUE;public$handler;public$ignoreEmptyStuff=TRUE;static
public$strictDTD=FALSE;public$scriptModule,$paragraphModule,$htmlModule,$imageModule,$linkModule,$phraseModule,$emoticonModule,$blockModule,$headingModule,$horizLineModule,$quoteModule,$listModule,$tableModule,$figureModule,$typographyModule,$longWordsModule;public$cleaner;private$linePatterns=array();private$blockPatterns=array();private$DOM;private$modules;private$marks=array();public$_classes,$_styles;public$_preBlockModules;private$_state=0;public
function
__construct(){$this->loadModules();$this->cleaner=new
TexyHtmlCleaner($this);foreach(TexyHtmlCleaner::$dtd
as$tag=>$dtd)$this->allowedTags[$tag]=is_array($dtd[0])?array_keys($dtd[0]):$dtd[0];$link=new
TexyLink('http://texy.info/');$link->modifier->title='The best text -> HTML converter and formatter';$link->label='Texy!';$this->linkModule->addReference('texy',$link);$link=new
TexyLink('http://www.google.com/search?q=%s');$this->linkModule->addReference('google',$link);$link=new
TexyLink('http://en.wikipedia.org/wiki/Special:Search?search=%s');$this->linkModule->addReference('wikipedia',$link);if(function_exists('mb_get_info')){$mb=mb_get_info();if($mb['func_overload']&2&&$mb['internal_encoding'][0]==='U'){mb_internal_encoding('pass');trigger_error('Texy: mb_internal_encoding changed to pass',E_USER_WARNING);}}}protected
function
loadModules(){$this->scriptModule=new
TexyScriptModule($this);$this->htmlModule=new
TexyHtmlModule($this);$this->imageModule=new
TexyImageModule($this);$this->phraseModule=new
TexyPhraseModule($this);$this->linkModule=new
TexyLinkModule($this);$this->emoticonModule=new
TexyEmoticonModule($this);$this->paragraphModule=new
TexyParagraphModule($this);$this->blockModule=new
TexyBlockModule($this);$this->headingModule=new
TexyHeadingModule($this);$this->horizLineModule=new
TexyHorizLineModule($this);$this->quoteModule=new
TexyQuoteModule($this);$this->listModule=new
TexyListModule($this);$this->tableModule=new
TexyTableModule($this);$this->figureModule=new
TexyFigureModule($this);$this->typographyModule=new
TexyTypographyModule($this);$this->longWordsModule=new
TexyLongWordsModule($this);}public
function
registerModule(TexyModule$module){$this->modules[]=$module;}public
function
registerLinePattern($handler,$pattern,$name){if(empty($this->allowed[$name]))return;$this->linePatterns[$name]=array('handler'=>$handler,'pattern'=>$pattern,);}public
function
registerBlockPattern($handler,$pattern,$name){if(empty($this->allowed[$name]))return;$this->blockPatterns[$name]=array('handler'=>$handler,'pattern'=>$pattern.'m',);}public
function
process($text,$singleLine=FALSE){$this->parse($text,$singleLine);return$this->toHtml();}public
function
processTypo($text){$text=TexyUtf::toUtf($text,$this->encoding);$text=self::normalize($text);$this->typographyModule->begin();$text=$this->typographyModule->postLine($text);return$text;}public
function
parse($text,$singleLine=FALSE){if($this->_state===1)throw
new
Exception('Parsing is in progress yet.');if($this->handler&&!is_object($this->handler))throw
new
Exception('$texy->handler must be object. See documentation.');$this->marks=array();$this->_state=1;if(is_array($this->allowedClasses))$this->_classes=array_flip($this->allowedClasses);else$this->_classes=$this->allowedClasses;if(is_array($this->allowedStyles))$this->_styles=array_flip($this->allowedStyles);else$this->_styles=$this->allowedStyles;$tmp=array($this->linePatterns,$this->blockPatterns);$text=TexyUtf::toUtf($text,$this->encoding);$text=self::normalize($text);while(strpos($text,"\t")!==FALSE)$text=preg_replace_callback('#^(.*)\t#mU',array($this,'tabCb'),$text);$this->_preBlockModules=array();foreach($this->modules
as$module){$module->begin();if($module
instanceof
ITexyPreBlock)$this->_preBlockModules[]=$module;}$this->DOM=TexyHtml::el();if($singleLine)$this->DOM->parseLine($this,$text);else$this->DOM->parseBlock($this,$text,TRUE);if(is_callable(array($this->handler,'afterParse')))$this->handler->afterParse($this,$this->DOM,$singleLine);list($this->linePatterns,$this->blockPatterns)=$tmp;$this->_state=2;}public
function
toHtml(){if($this->_state!==2)throw
new
Exception('Call $texy->parse() first.');$html=$this->_toHtml($this->DOM->export($this));if(!defined('TEXY_NOTICE_SHOWED')){$html.="\n<!-- by Texy2! -->";define('TEXY_NOTICE_SHOWED',TRUE);}$html=TexyUtf::utf2html($html,$this->encoding);return$html;}public
function
toText(){if($this->_state!==2)throw
new
Exception('Call $texy->parse() first.');$text=$this->_toText($this->DOM->export($this));$text=TexyUtf::utfTo($text,$this->encoding);return$text;}public
function
_toHtml($s){$s=self::unescapeHtml($s);$blocks=explode(self::CONTENT_BLOCK,$s);foreach($this->modules
as$module){if($module
instanceof
ITexyPostLine){foreach($blocks
as$n=>$s){if($n
%
2===0&&$s!=='')$blocks[$n]=$module->postLine($s);}}}$s=implode(self::CONTENT_BLOCK,$blocks);$s=self::escapeHtml($s);$s=$this->unProtect($s);$s=$this->cleaner->process($s);$s=self::unfreezeSpaces($s);return$s;}public
function
_toText($s){$save=$this->cleaner->lineWrap;$this->cleaner->lineWrap=FALSE;$s=$this->_toHtml($s);$this->cleaner->lineWrap=$save;$s=preg_replace('#<(script|style)(.*)</\\1>#Uis','',$s);$s=strip_tags($s);$s=preg_replace('#\n\s*\n\s*\n[\n\s]*\n#',"\n\n",$s);$s=Texy::unescapeHtml($s);$s=strtr($s,array("\xC2\xAD"=>'',"\xC2\xA0"=>' ',));return$s;}public
function
safeMode(){trigger_error('$texy->safeMode() is deprecated. Use TexyConfigurator::safeMode($texy)',E_USER_WARNING);TexyConfigurator::safeMode($this);}public
function
trustMode(){trigger_error('$texy->trustMode() is deprecated. Trust configuration is by default.',E_USER_WARNING);TexyConfigurator::trustMode($this);}static
public
function
freezeSpaces($s){return
strtr($s," \t\r\n","\x01\x02\x03\x04");}static
public
function
unfreezeSpaces($s){return
strtr($s,"\x01\x02\x03\x04"," \t\r\n");}static
public
function
normalize($s){$s=preg_replace('#[\x01-\x04\x14-\x1F]+#','',$s);$s=str_replace("\r\n","\n",$s);$s=strtr($s,"\r","\n");$s=preg_replace("#[\t ]+$#m",'',$s);$s=trim($s,"\n");return$s;}static
public
function
webalize($s,$charlist=NULL){$s=TexyUtf::utf2ascii($s);$s=strtolower($s);if($charlist)$charlist=preg_quote($charlist,'#');$s=preg_replace('#[^a-z0-9'.$charlist.']+#','-',$s);$s=trim($s,'-');return$s;}static
public
function
escapeHtml($s){return
str_replace(array('&','<','>'),array('&amp;','&lt;','&gt;'),$s);}static
public
function
unescapeHtml($s){if(strpos($s,'&')===FALSE)return$s;return
html_entity_decode($s,ENT_QUOTES,'UTF-8');}public
function
protect($child,$contentType=self::CONTENT_BLOCK){if($child==='')return'';$key=$contentType.strtr(base_convert(count($this->marks),10,8),'01234567',"\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F").$contentType;$this->marks[$key]=$child;return$key;}public
function
unProtect($html){return
strtr($html,$this->marks);}public
function
checkURL($URL,$type){if(!empty($this->urlSchemeFilters[$type])&&preg_match('#'.TEXY_URLSCHEME.'#iA',$URL)&&!preg_match($this->urlSchemeFilters[$type],$URL))return
FALSE;return
TRUE;}static
public
function
isRelative($URL){return!preg_match('#'.TEXY_URLSCHEME.'|[\#/?]#iA',$URL);}static
public
function
prependRoot($URL,$root){if($root==NULL||!self::isRelative($URL))return$URL;return
rtrim($root,'/\\').'/'.$URL;}public
function
getLinePatterns(){return$this->linePatterns;}public
function
getBlockPatterns(){return$this->blockPatterns;}public
function
getDOM(){return$this->DOM;}private
function
tabCb($m){return$m[1].str_repeat(' ',$this->tabWidth-strlen($m[1])%$this->tabWidth);}public
function
free(){foreach(array_keys(get_object_vars($this))as$key)$this->$key=NULL;}public
function
__clone(){throw
new
Exception("Clone is not supported.");}function
__get($nm){throw
new
Exception("Undefined property '".get_class($this)."::$$nm'");}function
__set($nm,$val){$this->__get($nm);}}?>