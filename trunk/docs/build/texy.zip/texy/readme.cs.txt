Co je Texy!
===========


Texy! je převaděč textu do formátovaného HTML kódu. Díky němu můžete psát
strukturované dokumenty i bez znalosti nebo použití jazyka HTML. Dokument
napíšete v přehledné, čistě textové, formě a Texy! jej automaticky převede do
validního (X)HTML kódu.


Texy! je jedním z nejkomplexnějších formátovačů. Umí zpracovávat obrázky,
odkazy, vnořené seznamy, tabulky a má také plnou podporu CSS a UTF-8.


Texy! formátuje text v souladu s typografickými pravidly. Zvláštní pozornost je
věnována národním specifikům. Texy! přetahuje jednopísmenné předložky a spojky
z konců řádků na řádek následující, rozděluje příliš dlouhá slova podle slabik
a podobně.


Kód je napsán v PHP s plným využitím objektů. Navržen je tak, aby jeho
rozšíření nebo přizpůsobení specifickým potřebám bylo co nejjednodušší a obešlo
se bez zásahu do zdrojového kódu.


Texy je sexy!




Podpořte Texy!
-------------

Pokud byste rádi vyjádřili uznání za čas, který autor strávil jeho vývojem,
nebo pokud Vám Texy dobře slouží a chtěli byste podpořit jeho další vývoj,
pošlete prosím příspěvek v jakékoliv výši (viz http://texy.info/cs/prispejte)

Texy můžete podpořit také umístěním ikonky na své stránky. Ikonky a vzorový
HTML kód najdete v adresáři /icons/




Copyright
---------

Texy! (C) David Grudl, 2004-2007
